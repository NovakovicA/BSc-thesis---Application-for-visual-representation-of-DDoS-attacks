﻿Public Class ErrorSite

    Public Sub setTitleAndBody(ByVal title As String, ByVal body As String)
        LBLTitle.Text = title
        LBLBody.Text = body
    End Sub
End Class