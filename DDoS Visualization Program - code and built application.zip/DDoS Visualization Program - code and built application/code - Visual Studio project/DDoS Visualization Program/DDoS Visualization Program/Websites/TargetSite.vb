﻿Public Class TargetSite
    Public Overrides Sub WebsiteLoad()
        LBL1.Parent = PBMain
    End Sub
End Class