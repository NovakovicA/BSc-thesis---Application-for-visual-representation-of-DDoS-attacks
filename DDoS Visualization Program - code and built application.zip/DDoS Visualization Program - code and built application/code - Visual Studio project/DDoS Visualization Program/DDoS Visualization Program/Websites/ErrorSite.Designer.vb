﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ErrorSite
    Inherits Site

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLTitle = New System.Windows.Forms.Label()
        Me.LBLBody = New System.Windows.Forms.Label()
        Me.Website.SuspendLayout()
        Me.SuspendLayout()
        '
        'Website
        '
        Me.Website.BackColor = System.Drawing.Color.Azure
        Me.Website.Controls.Add(Me.LBLBody)
        Me.Website.Controls.Add(Me.LBLTitle)
        '
        'LBLTitle
        '
        Me.LBLTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLTitle.Location = New System.Drawing.Point(118, 28)
        Me.LBLTitle.Name = "LBLTitle"
        Me.LBLTitle.Size = New System.Drawing.Size(473, 43)
        Me.LBLTitle.TabIndex = 0
        Me.LBLTitle.Text = "Title"
        Me.LBLTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LBLBody
        '
        Me.LBLBody.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLBody.Location = New System.Drawing.Point(12, 175)
        Me.LBLBody.Name = "LBLBody"
        Me.LBLBody.Size = New System.Drawing.Size(716, 236)
        Me.LBLBody.TabIndex = 1
        Me.LBLBody.Text = "Body"
        '
        'ErrorSite
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 420)
        Me.Name = "ErrorSite"
        Me.Text = "ErrorSite"
        Me.Website.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents LBLTitle As Label
    Friend WithEvents LBLBody As Label
End Class
