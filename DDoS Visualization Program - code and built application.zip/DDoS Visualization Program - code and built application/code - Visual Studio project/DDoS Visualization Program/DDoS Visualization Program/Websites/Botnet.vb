﻿
Public Class Botnet

    'L4-TCP
    'L4-UDP
    'L4-SYN
    'L7-HTTP GET
    'L7-XMLRPC

    Private Shared Mutex As New Object
    Public Overrides Sub WebsiteLoad()
        LBLUsername.Parent = PBLogin
        LBLPassword.Parent = PBLogin
        LBLStatus.Parent = PBLogin
    End Sub

    Private Sub UpdateSelectionNumber(sender As Object, e As EventArgs) Handles ListView.SelectedIndexChanged
        LBLSelected.Text = "Number of selected bots: " & CStr(ListView.SelectedItems.Count())
    End Sub

    Private Sub BTNSelectAll_Click(sender As Object, e As EventArgs) Handles BTNSelectAll.Click
        For I = 0 To ListView.Items.Count - 1
            ListView.Items(I).Selected = True
        Next
    End Sub

    Private Sub BTNLogin_Click(sender As Object, e As EventArgs) Handles BTNLogin.Click
        If (String.Compare(TXTUsername.Text, "admin", True) = 0 And String.Compare(TXTPassword.Text, "123") = 0) Then
            PanelLogin.Hide()
            RefreshBots()
            CBAttackType.SelectedIndex = 0
            TXTPort.Text = "80"
            TXTTime.Text = "0"
            TXTTarget.Text = "target.com"
        Else
            TXTUsername.Text = ""
            TXTPassword.Text = ""
            LBLStatus.Text = "Invalid username or password."
        End If
    End Sub

    Private Async Sub BTNStart_Click(sender As Object, e As EventArgs) Handles BTNStart.Click
        If (String.Compare(TXTTarget.Text, "target.com", True) <> 0 And String.Compare(TXTTarget.Text, "1.1.1.1") <> 0) Then
            MessageBox.Show("Error - simulation only allows ddosing of the target server.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTPort.Text) Then
            MessageBox.Show("Error - port must be a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTTime.Text) Then
            MessageBox.Show("Error - attack time must be a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf CInt(TXTTime.Text) < 0 Then
            MessageBox.Show("Error - attack time must be greater or equal to 0.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf (IsNumeric(TXTPort.Text) And Not (CInt(TXTPort.Text) > -1 And CInt(TXTPort.Text) < 65536)) Then
            MessageBox.Show("Error - port must be a number in range from 0 to 65535.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf ListView.SelectedItems.Count() = 0 Then
            MessageBox.Show("Please select at least one attacking bot.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim bq As New Queue(Of Bot)
        Dim b As Integer = 0

        SyncLock Mutex
            Try
                For Each i As ListViewItem In ListView.SelectedItems
                    If (String.Compare(Bots(i.Index).GetStatus(), "Idle")) = 0 Then
                        Bots(i.Index).SetStatus(CBAttackType.SelectedItem.ToString() & " " & TXTTarget.Text & ":" & TXTPort.Text)

                        If (((String.Compare(CBAttackType.SelectedItem.ToString(), "L4-TCP") = 0) Or (String.Compare(CBAttackType.SelectedItem.ToString(), "L4-SYN") = 0)) And (Not MainWindow.target.GetOpenPorts().Contains(CInt(TXTPort.Text)))) Then
                            Continue For
                        ElseIf (((String.Compare(CBAttackType.SelectedItem.ToString(), "L7-XMLRPC") = 0) Or (String.Compare(CBAttackType.SelectedItem.ToString(), "L7-HTTP GET") = 0)) And ((Not MainWindow.target.isWebServer()) Or CInt(TXTPort.Text) <> 80)) Then
                            Continue For
                        End If


                        If String.Compare(CBAttackType.SelectedItem.ToString(), "L4-SYN") = 0 Then
                            Bots(i.Index).SetCurrentBandwidth(1)
                            b += 1
                            MainWindow.target.SetSYNAttackSpeed(MainWindow.target.GetSYNAttackSpeed() + 200)
                        ElseIf String.Compare(CBAttackType.SelectedItem.ToString(), "L7-XMLRPC") = 0 Then
                            Bots(i.Index).SetCurrentBandwidth(Math.Ceiling(Bots(i.Index).GetBandwidth() / 4))
                            For j = 0 To MainWindow.reflectionServers.Length() - 1
                                Dim serv As Server = MainWindow.reflectionServers(j)
                                serv.SetCurrentBandwidth(serv.GetCurrentBandwidth() + (Math.Ceiling(Bots(i.Index).GetBandwidth() / 2)))
                                b += Math.Ceiling(Bots(i.Index).GetBandwidth() / 2)
                                serv.AddLogEntry("Reflecting DDoS attack - from host " & Bots(i.Index).GetIPv4() & " to target [" & TXTTarget.Text & "].")
                            Next
                        Else
                            Bots(i.Index).SetCurrentBandwidth(Bots(i.Index).GetBandwidth())
                            b += Bots(i.Index).GetBandwidth()
                        End If


                        bq.Enqueue(Bots(i.Index))

                        Bots(i.Index).AddLogEntry("Started DDoS on target [" & TXTTarget.Text & "] with method " & CBAttackType.SelectedItem.ToString() & ".")
                        If String.Compare(CBAttackType.SelectedItem.ToString(), "L7-XMLRPC") <> 0 Then
                            MainWindow.target.AddLogEntry("Detected DDoS attack - method " & CBAttackType.SelectedItem.ToString() & " from host " & Bots(i.Index).GetIPv4() & ".")
                        End If
                    End If
                Next


                If String.Compare(CBAttackType.SelectedItem.ToString(), "L7-XMLRPC") = 0 Then
                    For j = 0 To MainWindow.reflectionServers.Length() - 1
                        MainWindow.target.AddLogEntry("Detected DDoS attack - method " & "L7-HTTP GET" & " from host " & MainWindow.reflectionServers(j).GetIPv4() & ".")
                    Next
                End If

                MainWindow.target.SetCurrentBandwidth(MainWindow.target.GetCurrentBandwidth() + b)
                ListView.SelectedItems.Clear()
                RefreshBots()
            Catch ex As Exception
            End Try
        End SyncLock

        If (CInt(TXTTime.Text) = 0) Then
            Return
        Else
            Await Task.Delay(CInt(TXTTime.Text) * 1000)
        End If

        SyncLock Mutex
            Try
                b = 0
                For Each bot As Bot In bq
                    If (bot.GetStatus().StartsWith("L")) Then

                        If bot.GetStatus().StartsWith("L4-SYN") Then
                            bot.SetCurrentBandwidth(0)
                            b += 1
                            MainWindow.target.SetSYNAttackSpeed(MainWindow.target.GetSYNAttackSpeed() - 200)
                        ElseIf bot.GetStatus().StartsWith("L7-XMLRPC") Then
                            bot.SetCurrentBandwidth(0)
                            For j = 0 To MainWindow.reflectionServers.Length() - 1
                                Dim serv As Server = MainWindow.reflectionServers(j)
                                serv.SetCurrentBandwidth(serv.GetCurrentBandwidth() - Math.Ceiling(bot.GetBandwidth() / 2))
                                b += Math.Ceiling(bot.GetBandwidth() / 2)
                                If (serv.GetCurrentBandwidth() = 0) Then
                                    MainWindow.target.AddLogEntry("DDoS attack from host " & serv.GetIPv4() & " has stopped.")
                                    serv.AddLogEntry("Stopped reflecting DDoS attacks.")
                                End If
                            Next
                        Else
                            bot.SetCurrentBandwidth(0)
                            b += bot.GetBandwidth()
                        End If

                        bot.AddLogEntry("DDoS attack stopped.")
                        If Not bot.GetStatus().StartsWith("L7-XMLRPC") Then
                            MainWindow.target.AddLogEntry("DDoS attack from host " & bot.GetIPv4() & " has stopped.")
                        End If
                        bot.SetStatus("Idle")
                    End If
                Next
                MainWindow.target.SetCurrentBandwidth(MainWindow.target.GetCurrentBandwidth() - b)
                RefreshBots()
            Catch ex As Exception
            End Try
            End SyncLock
    End Sub

    Private Sub BTNStop_Click(sender As Object, e As EventArgs) Handles BTNStop.Click
        SyncLock Mutex
            Dim b As Integer = 0
            For Each i As ListViewItem In ListView.SelectedItems
                If (Bots(i.Index).GetStatus().StartsWith("L")) Then

                    If Bots(i.Index).GetStatus().StartsWith("L4-SYN") Then
                        Bots(i.Index).SetCurrentBandwidth(0)
                        b += 1
                        MainWindow.target.SetSYNAttackSpeed(MainWindow.target.GetSYNAttackSpeed() - 200)
                    ElseIf Bots(i.Index).GetStatus().StartsWith("L7-XMLRPC") Then
                        Bots(i.Index).SetCurrentBandwidth(0)
                        For j = 0 To MainWindow.reflectionServers.Length() - 1
                            Dim serv As Server = MainWindow.reflectionServers(j)
                            serv.SetCurrentBandwidth(serv.GetCurrentBandwidth() - Math.Ceiling(Bots(i.Index).GetBandwidth() / 2))
                            b += Math.Ceiling(Bots(i.Index).GetBandwidth() / 2)
                            If (serv.GetCurrentBandwidth() = 0) Then
                                MainWindow.target.AddLogEntry("DDoS attack from host " & serv.GetIPv4() & " has stopped.")
                                serv.AddLogEntry("Stopped reflecting DDoS attacks.")
                            End If
                        Next
                    Else
                        Bots(i.Index).SetCurrentBandwidth(0)
                        b += Bots(i.Index).GetBandwidth()
                    End If

                    Bots(i.Index).AddLogEntry("DDoS attack stopped.")
                    If Not Bots(i.Index).GetStatus().StartsWith("L7-XMLRPC") Then
                        MainWindow.target.AddLogEntry("DDoS attack from host " & Bots(i.Index).GetIPv4() & " has stopped.")
                    End If
                    Bots(i.Index).SetStatus("Idle")
                End If
            Next
            MainWindow.target.SetCurrentBandwidth(MainWindow.target.GetCurrentBandwidth() - b)
            ListView.SelectedItems.Clear()
            RefreshBots()
        End SyncLock
    End Sub

    Private Sub RefreshBots()
        ListView.Items.Clear()
        Dim ind As Integer = 1
        For Each b As Bot In Bots
            Dim item As New ListViewItem
            item.Text = "Bot#" & ind
            item.SubItems.Add(b.GetIPv4())
            Select Case b.GetTypeHost()
                Case 1
                    item.SubItems.Add("Desktop")
                Case 2
                    item.SubItems.Add("Laptop")
                Case 3
                    item.SubItems.Add("Router")
                Case 4
                    item.SubItems.Add("Cam")
                Case Else
                    item.SubItems.Add("Server")
            End Select
            item.SubItems.Add(b.GetStatus())
            ListView.Items.Add(item)
            ind += 1
        Next
    End Sub



End Class