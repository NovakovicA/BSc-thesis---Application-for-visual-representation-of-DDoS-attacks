﻿
Public Class Site
    Public Overridable Sub WebsiteLoad()
    End Sub

End Class