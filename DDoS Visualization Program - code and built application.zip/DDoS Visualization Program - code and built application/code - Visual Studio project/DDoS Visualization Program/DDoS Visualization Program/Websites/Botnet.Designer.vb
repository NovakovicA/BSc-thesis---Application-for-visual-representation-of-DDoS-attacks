﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Botnet
    Inherits Site

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.LBLBotnetPanel = New System.Windows.Forms.Label()
        Me.BTNSelectAll = New System.Windows.Forms.Button()
        Me.LBLSelected = New System.Windows.Forms.Label()
        Me.CBAttackType = New System.Windows.Forms.ComboBox()
        Me.LBLAttackType = New System.Windows.Forms.Label()
        Me.LBLPort = New System.Windows.Forms.Label()
        Me.TXTTarget = New System.Windows.Forms.TextBox()
        Me.LBLTarget = New System.Windows.Forms.Label()
        Me.GroupBox = New System.Windows.Forms.GroupBox()
        Me.BTNStop = New System.Windows.Forms.Button()
        Me.BTNStart = New System.Windows.Forms.Button()
        Me.TXTTime = New System.Windows.Forms.TextBox()
        Me.LBLAttackTime = New System.Windows.Forms.Label()
        Me.TXTPort = New System.Windows.Forms.TextBox()
        Me.PanelLogin = New System.Windows.Forms.Panel()
        Me.LBLStatus = New System.Windows.Forms.Label()
        Me.BTNLogin = New System.Windows.Forms.Button()
        Me.TXTPassword = New System.Windows.Forms.TextBox()
        Me.TXTUsername = New System.Windows.Forms.TextBox()
        Me.LBLPassword = New System.Windows.Forms.Label()
        Me.LBLUsername = New System.Windows.Forms.Label()
        Me.PBLogin = New System.Windows.Forms.PictureBox()
        Me.Website.SuspendLayout()
        Me.GroupBox.SuspendLayout()
        Me.PanelLogin.SuspendLayout()
        CType(Me.PBLogin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Website
        '
        Me.Website.BackColor = System.Drawing.Color.DarkGray
        Me.Website.BackgroundImage = Global.DDoS_Visualization_Program.My.Resources.Resources.botnetlogin
        Me.Website.Controls.Add(Me.PanelLogin)
        Me.Website.Controls.Add(Me.GroupBox)
        Me.Website.Controls.Add(Me.LBLSelected)
        Me.Website.Controls.Add(Me.BTNSelectAll)
        Me.Website.Controls.Add(Me.LBLBotnetPanel)
        Me.Website.Controls.Add(Me.ListView)
        '
        'ListView
        '
        Me.ListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.ListView.FullRowSelect = True
        Me.ListView.GridLines = True
        Me.ListView.Location = New System.Drawing.Point(9, 46)
        Me.ListView.Name = "ListView"
        Me.ListView.Size = New System.Drawing.Size(390, 362)
        Me.ListView.TabIndex = 0
        Me.ListView.UseCompatibleStateImageBehavior = False
        Me.ListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Bot ID"
        Me.ColumnHeader1.Width = 74
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "IPv4"
        Me.ColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader2.Width = 125
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Type"
        Me.ColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader3.Width = 92
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Status"
        Me.ColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader4.Width = 160
        '
        'LBLBotnetPanel
        '
        Me.LBLBotnetPanel.AutoSize = True
        Me.LBLBotnetPanel.Font = New System.Drawing.Font("Trebuchet MS", 15.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLBotnetPanel.Location = New System.Drawing.Point(155, 11)
        Me.LBLBotnetPanel.Name = "LBLBotnetPanel"
        Me.LBLBotnetPanel.Size = New System.Drawing.Size(249, 32)
        Me.LBLBotnetPanel.TabIndex = 2
        Me.LBLBotnetPanel.Text = "Botnet Control Panel"
        '
        'BTNSelectAll
        '
        Me.BTNSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNSelectAll.Location = New System.Drawing.Point(650, 51)
        Me.BTNSelectAll.Name = "BTNSelectAll"
        Me.BTNSelectAll.Size = New System.Drawing.Size(78, 27)
        Me.BTNSelectAll.TabIndex = 3
        Me.BTNSelectAll.Text = "Select all"
        Me.BTNSelectAll.UseVisualStyleBackColor = True
        '
        'LBLSelected
        '
        Me.LBLSelected.AutoSize = True
        Me.LBLSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSelected.Location = New System.Drawing.Point(401, 53)
        Me.LBLSelected.Name = "LBLSelected"
        Me.LBLSelected.Size = New System.Drawing.Size(211, 20)
        Me.LBLSelected.TabIndex = 4
        Me.LBLSelected.Text = "Number of selected bots: 0"
        '
        'CBAttackType
        '
        Me.CBAttackType.BackColor = System.Drawing.Color.Silver
        Me.CBAttackType.FormattingEnabled = True
        Me.CBAttackType.Items.AddRange(New Object() {"L4-TCP", "L4-UDP", "L4-SYN", "L7-HTTP GET", "L7-XMLRPC"})
        Me.CBAttackType.Location = New System.Drawing.Point(9, 108)
        Me.CBAttackType.Name = "CBAttackType"
        Me.CBAttackType.Size = New System.Drawing.Size(179, 24)
        Me.CBAttackType.TabIndex = 5
        '
        'LBLAttackType
        '
        Me.LBLAttackType.AutoSize = True
        Me.LBLAttackType.Location = New System.Drawing.Point(6, 88)
        Me.LBLAttackType.Name = "LBLAttackType"
        Me.LBLAttackType.Size = New System.Drawing.Size(87, 17)
        Me.LBLAttackType.TabIndex = 6
        Me.LBLAttackType.Text = "Attack Type:"
        '
        'LBLPort
        '
        Me.LBLPort.AutoSize = True
        Me.LBLPort.Location = New System.Drawing.Point(205, 38)
        Me.LBLPort.Name = "LBLPort"
        Me.LBLPort.Size = New System.Drawing.Size(38, 17)
        Me.LBLPort.TabIndex = 7
        Me.LBLPort.Text = "Port:"
        '
        'TXTTarget
        '
        Me.TXTTarget.BackColor = System.Drawing.Color.Silver
        Me.TXTTarget.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXTTarget.Location = New System.Drawing.Point(9, 58)
        Me.TXTTarget.Name = "TXTTarget"
        Me.TXTTarget.Size = New System.Drawing.Size(179, 22)
        Me.TXTTarget.TabIndex = 8
        '
        'LBLTarget
        '
        Me.LBLTarget.AutoSize = True
        Me.LBLTarget.Location = New System.Drawing.Point(6, 38)
        Me.LBLTarget.Name = "LBLTarget"
        Me.LBLTarget.Size = New System.Drawing.Size(157, 17)
        Me.LBLTarget.TabIndex = 9
        Me.LBLTarget.Text = "Target host(IP/domain):"
        '
        'GroupBox
        '
        Me.GroupBox.BackColor = System.Drawing.Color.Gray
        Me.GroupBox.Controls.Add(Me.BTNStop)
        Me.GroupBox.Controls.Add(Me.BTNStart)
        Me.GroupBox.Controls.Add(Me.TXTTime)
        Me.GroupBox.Controls.Add(Me.LBLAttackTime)
        Me.GroupBox.Controls.Add(Me.TXTPort)
        Me.GroupBox.Controls.Add(Me.LBLTarget)
        Me.GroupBox.Controls.Add(Me.TXTTarget)
        Me.GroupBox.Controls.Add(Me.LBLAttackType)
        Me.GroupBox.Controls.Add(Me.LBLPort)
        Me.GroupBox.Controls.Add(Me.CBAttackType)
        Me.GroupBox.Location = New System.Drawing.Point(405, 98)
        Me.GroupBox.Name = "GroupBox"
        Me.GroupBox.Size = New System.Drawing.Size(323, 310)
        Me.GroupBox.TabIndex = 10
        Me.GroupBox.TabStop = False
        Me.GroupBox.Text = "DDoS"
        '
        'BTNStop
        '
        Me.BTNStop.BackColor = System.Drawing.Color.Silver
        Me.BTNStop.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.BTNStop.FlatAppearance.BorderSize = 2
        Me.BTNStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNStop.Location = New System.Drawing.Point(165, 242)
        Me.BTNStop.Name = "BTNStop"
        Me.BTNStop.Size = New System.Drawing.Size(117, 31)
        Me.BTNStop.TabIndex = 14
        Me.BTNStop.Text = "Stop DDoS"
        Me.BTNStop.UseVisualStyleBackColor = False
        '
        'BTNStart
        '
        Me.BTNStart.BackColor = System.Drawing.Color.Silver
        Me.BTNStart.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.BTNStart.FlatAppearance.BorderSize = 2
        Me.BTNStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNStart.Location = New System.Drawing.Point(23, 242)
        Me.BTNStart.Name = "BTNStart"
        Me.BTNStart.Size = New System.Drawing.Size(117, 31)
        Me.BTNStart.TabIndex = 13
        Me.BTNStart.Text = "Start DDoS"
        Me.BTNStart.UseVisualStyleBackColor = False
        '
        'TXTTime
        '
        Me.TXTTime.BackColor = System.Drawing.Color.Silver
        Me.TXTTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXTTime.Location = New System.Drawing.Point(208, 110)
        Me.TXTTime.Name = "TXTTime"
        Me.TXTTime.Size = New System.Drawing.Size(74, 22)
        Me.TXTTime.TabIndex = 12
        '
        'LBLAttackTime
        '
        Me.LBLAttackTime.AutoSize = True
        Me.LBLAttackTime.Location = New System.Drawing.Point(205, 88)
        Me.LBLAttackTime.Name = "LBLAttackTime"
        Me.LBLAttackTime.Size = New System.Drawing.Size(102, 17)
        Me.LBLAttackTime.TabIndex = 11
        Me.LBLAttackTime.Text = "Attack time (s):"
        '
        'TXTPort
        '
        Me.TXTPort.BackColor = System.Drawing.Color.Silver
        Me.TXTPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXTPort.Location = New System.Drawing.Point(208, 58)
        Me.TXTPort.Name = "TXTPort"
        Me.TXTPort.Size = New System.Drawing.Size(74, 22)
        Me.TXTPort.TabIndex = 10
        '
        'PanelLogin
        '
        Me.PanelLogin.Controls.Add(Me.LBLStatus)
        Me.PanelLogin.Controls.Add(Me.BTNLogin)
        Me.PanelLogin.Controls.Add(Me.TXTPassword)
        Me.PanelLogin.Controls.Add(Me.TXTUsername)
        Me.PanelLogin.Controls.Add(Me.LBLPassword)
        Me.PanelLogin.Controls.Add(Me.LBLUsername)
        Me.PanelLogin.Controls.Add(Me.PBLogin)
        Me.PanelLogin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelLogin.Location = New System.Drawing.Point(0, 0)
        Me.PanelLogin.Name = "PanelLogin"
        Me.PanelLogin.Size = New System.Drawing.Size(740, 420)
        Me.PanelLogin.TabIndex = 15
        '
        'LBLStatus
        '
        Me.LBLStatus.AutoSize = True
        Me.LBLStatus.BackColor = System.Drawing.Color.Transparent
        Me.LBLStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLStatus.ForeColor = System.Drawing.Color.Red
        Me.LBLStatus.Location = New System.Drawing.Point(383, 243)
        Me.LBLStatus.Name = "LBLStatus"
        Me.LBLStatus.Size = New System.Drawing.Size(0, 20)
        Me.LBLStatus.TabIndex = 6
        '
        'BTNLogin
        '
        Me.BTNLogin.Location = New System.Drawing.Point(387, 299)
        Me.BTNLogin.Name = "BTNLogin"
        Me.BTNLogin.Size = New System.Drawing.Size(152, 35)
        Me.BTNLogin.TabIndex = 5
        Me.BTNLogin.Text = "Login"
        Me.BTNLogin.UseVisualStyleBackColor = True
        '
        'TXTPassword
        '
        Me.TXTPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TXTPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTPassword.Location = New System.Drawing.Point(327, 174)
        Me.TXTPassword.Name = "TXTPassword"
        Me.TXTPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TXTPassword.Size = New System.Drawing.Size(212, 36)
        Me.TXTPassword.TabIndex = 4
        '
        'TXTUsername
        '
        Me.TXTUsername.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TXTUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTUsername.Location = New System.Drawing.Point(327, 115)
        Me.TXTUsername.Name = "TXTUsername"
        Me.TXTUsername.Size = New System.Drawing.Size(212, 36)
        Me.TXTUsername.TabIndex = 3
        '
        'LBLPassword
        '
        Me.LBLPassword.AutoSize = True
        Me.LBLPassword.BackColor = System.Drawing.Color.Transparent
        Me.LBLPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLPassword.ForeColor = System.Drawing.Color.White
        Me.LBLPassword.Location = New System.Drawing.Point(162, 181)
        Me.LBLPassword.Name = "LBLPassword"
        Me.LBLPassword.Size = New System.Drawing.Size(131, 29)
        Me.LBLPassword.TabIndex = 2
        Me.LBLPassword.Text = "Password:"
        '
        'LBLUsername
        '
        Me.LBLUsername.AutoSize = True
        Me.LBLUsername.BackColor = System.Drawing.Color.Transparent
        Me.LBLUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLUsername.ForeColor = System.Drawing.Color.White
        Me.LBLUsername.Location = New System.Drawing.Point(156, 122)
        Me.LBLUsername.Name = "LBLUsername"
        Me.LBLUsername.Size = New System.Drawing.Size(137, 29)
        Me.LBLUsername.TabIndex = 1
        Me.LBLUsername.Text = "Username:"
        '
        'PBLogin
        '
        Me.PBLogin.BackColor = System.Drawing.Color.Transparent
        Me.PBLogin.BackgroundImage = Global.DDoS_Visualization_Program.My.Resources.Resources.botnetlogin
        Me.PBLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PBLogin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PBLogin.Location = New System.Drawing.Point(0, 0)
        Me.PBLogin.Name = "PBLogin"
        Me.PBLogin.Size = New System.Drawing.Size(740, 420)
        Me.PBLogin.TabIndex = 0
        Me.PBLogin.TabStop = False
        '
        'Botnet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 420)
        Me.Name = "Botnet"
        Me.Text = "Test"
        Me.Website.ResumeLayout(False)
        Me.Website.PerformLayout()
        Me.GroupBox.ResumeLayout(False)
        Me.GroupBox.PerformLayout()
        Me.PanelLogin.ResumeLayout(False)
        Me.PanelLogin.PerformLayout()
        CType(Me.PBLogin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListView As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents BTNSelectAll As Button
    Friend WithEvents LBLBotnetPanel As Label
    Friend WithEvents LBLSelected As Label
    Friend WithEvents GroupBox As GroupBox
    Friend WithEvents TXTPort As TextBox
    Friend WithEvents LBLTarget As Label
    Friend WithEvents TXTTarget As TextBox
    Friend WithEvents LBLAttackType As Label
    Friend WithEvents LBLPort As Label
    Friend WithEvents CBAttackType As ComboBox
    Friend WithEvents TXTTime As TextBox
    Friend WithEvents LBLAttackTime As Label
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents BTNStop As Button
    Friend WithEvents BTNStart As Button
    Friend WithEvents PanelLogin As Panel
    Friend WithEvents PBLogin As PictureBox
    Friend WithEvents LBLPassword As Label
    Friend WithEvents LBLUsername As Label
    Friend WithEvents LBLStatus As Label
    Friend WithEvents BTNLogin As Button
    Friend WithEvents TXTPassword As TextBox
    Friend WithEvents TXTUsername As TextBox
End Class
