﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TargetSite
    Inherits Site

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PBMain = New System.Windows.Forms.PictureBox()
        Me.LBL1 = New System.Windows.Forms.Label()
        Me.Website.SuspendLayout()
        CType(Me.PBMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Website
        '
        Me.Website.Controls.Add(Me.LBL1)
        Me.Website.Controls.Add(Me.PBMain)
        '
        'PBMain
        '
        Me.PBMain.BackgroundImage = Global.DDoS_Visualization_Program.My.Resources.Resources.targetsitepicture
        Me.PBMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PBMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PBMain.Location = New System.Drawing.Point(0, 0)
        Me.PBMain.Name = "PBMain"
        Me.PBMain.Size = New System.Drawing.Size(740, 420)
        Me.PBMain.TabIndex = 0
        Me.PBMain.TabStop = False
        '
        'LBL1
        '
        Me.LBL1.AutoSize = True
        Me.LBL1.BackColor = System.Drawing.Color.Transparent
        Me.LBL1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL1.Location = New System.Drawing.Point(170, 72)
        Me.LBL1.Name = "LBL1"
        Me.LBL1.Size = New System.Drawing.Size(357, 25)
        Me.LBL1.TabIndex = 1
        Me.LBL1.Text = "Welcome to the example target website."
        '
        'TargetSite
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 420)
        Me.Name = "TargetSite"
        Me.Text = "TargetSite"
        Me.Website.ResumeLayout(False)
        Me.Website.PerformLayout()
        CType(Me.PBMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PBMain As PictureBox
    Friend WithEvents LBL1 As Label
End Class
