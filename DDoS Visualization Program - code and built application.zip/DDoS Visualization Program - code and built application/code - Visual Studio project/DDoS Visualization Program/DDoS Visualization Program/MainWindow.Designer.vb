﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainWindow))
        Me.SplitContainer = New System.Windows.Forms.SplitContainer()
        Me.BTNAbout = New System.Windows.Forms.Button()
        Me.TXTTargetBand = New System.Windows.Forms.TextBox()
        Me.LBLTargetBand = New System.Windows.Forms.Label()
        Me.LBLRefServerBand = New System.Windows.Forms.Label()
        Me.TXTRefBand = New System.Windows.Forms.TextBox()
        Me.BTNGenerate = New System.Windows.Forms.Button()
        Me.LBLDel = New System.Windows.Forms.Label()
        Me.TXTDel = New System.Windows.Forms.TextBox()
        Me.LBLAvgBand = New System.Windows.Forms.Label()
        Me.TXTAvgBotBand = New System.Windows.Forms.TextBox()
        Me.TXTNumberOfBots = New System.Windows.Forms.TextBox()
        Me.LBLNumOfBots = New System.Windows.Forms.Label()
        Me.GB1 = New System.Windows.Forms.GroupBox()
        Me.TXTDelay = New System.Windows.Forms.TextBox()
        Me.TXTBandwidth = New System.Windows.Forms.TextBox()
        Me.TXTIPv4 = New System.Windows.Forms.TextBox()
        Me.TXTType = New System.Windows.Forms.TextBox()
        Me.LBLType1 = New System.Windows.Forms.Label()
        Me.LBLIP1 = New System.Windows.Forms.Label()
        Me.LBLBandwidth1 = New System.Windows.Forms.Label()
        Me.LBLDelay1 = New System.Windows.Forms.Label()
        Me.LBLBotnetType = New System.Windows.Forms.Label()
        Me.CBBotnetType = New System.Windows.Forms.ComboBox()
        CType(Me.SplitContainer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer.Panel2.SuspendLayout()
        Me.SplitContainer.SuspendLayout()
        Me.GB1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer
        '
        Me.SplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer.Name = "SplitContainer"
        '
        'SplitContainer.Panel1
        '
        Me.SplitContainer.Panel1.AutoScroll = True
        '
        'SplitContainer.Panel2
        '
        Me.SplitContainer.Panel2.AutoScroll = True
        Me.SplitContainer.Panel2.Controls.Add(Me.BTNAbout)
        Me.SplitContainer.Panel2.Controls.Add(Me.TXTTargetBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLTargetBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLRefServerBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.TXTRefBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.BTNGenerate)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLDel)
        Me.SplitContainer.Panel2.Controls.Add(Me.TXTDel)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLAvgBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.TXTAvgBotBand)
        Me.SplitContainer.Panel2.Controls.Add(Me.TXTNumberOfBots)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLNumOfBots)
        Me.SplitContainer.Panel2.Controls.Add(Me.GB1)
        Me.SplitContainer.Panel2.Controls.Add(Me.LBLBotnetType)
        Me.SplitContainer.Panel2.Controls.Add(Me.CBBotnetType)
        Me.SplitContainer.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SplitContainer.Size = New System.Drawing.Size(1902, 1033)
        Me.SplitContainer.SplitterDistance = 1434
        Me.SplitContainer.TabIndex = 0
        '
        'BTNAbout
        '
        Me.BTNAbout.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BTNAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNAbout.Location = New System.Drawing.Point(76, 697)
        Me.BTNAbout.Name = "BTNAbout"
        Me.BTNAbout.Size = New System.Drawing.Size(166, 43)
        Me.BTNAbout.TabIndex = 17
        Me.BTNAbout.Text = "About"
        Me.BTNAbout.UseVisualStyleBackColor = False
        '
        'TXTTargetBand
        '
        Me.TXTTargetBand.Location = New System.Drawing.Point(248, 482)
        Me.TXTTargetBand.Name = "TXTTargetBand"
        Me.TXTTargetBand.Size = New System.Drawing.Size(166, 22)
        Me.TXTTargetBand.TabIndex = 16
        Me.TXTTargetBand.Text = "10000"
        '
        'LBLTargetBand
        '
        Me.LBLTargetBand.AutoSize = True
        Me.LBLTargetBand.Location = New System.Drawing.Point(26, 482)
        Me.LBLTargetBand.Name = "LBLTargetBand"
        Me.LBLTargetBand.Size = New System.Drawing.Size(214, 17)
        Me.LBLTargetBand.TabIndex = 15
        Me.LBLTargetBand.Text = "Target server bandwidth (Mbps):"
        '
        'LBLRefServerBand
        '
        Me.LBLRefServerBand.AutoSize = True
        Me.LBLRefServerBand.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLRefServerBand.Location = New System.Drawing.Point(3, 454)
        Me.LBLRefServerBand.Name = "LBLRefServerBand"
        Me.LBLRefServerBand.Size = New System.Drawing.Size(235, 17)
        Me.LBLRefServerBand.TabIndex = 14
        Me.LBLRefServerBand.Text = "Reflection server bandwidth (Mbps):"
        '
        'TXTRefBand
        '
        Me.TXTRefBand.Location = New System.Drawing.Point(248, 451)
        Me.TXTRefBand.Name = "TXTRefBand"
        Me.TXTRefBand.Size = New System.Drawing.Size(166, 22)
        Me.TXTRefBand.TabIndex = 13
        Me.TXTRefBand.Text = "5000"
        '
        'BTNGenerate
        '
        Me.BTNGenerate.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BTNGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTNGenerate.Location = New System.Drawing.Point(76, 633)
        Me.BTNGenerate.Name = "BTNGenerate"
        Me.BTNGenerate.Size = New System.Drawing.Size(166, 43)
        Me.BTNGenerate.TabIndex = 12
        Me.BTNGenerate.Text = "Generate Network"
        Me.BTNGenerate.UseVisualStyleBackColor = False
        '
        'LBLDel
        '
        Me.LBLDel.AutoSize = True
        Me.LBLDel.Location = New System.Drawing.Point(26, 358)
        Me.LBLDel.Name = "LBLDel"
        Me.LBLDel.Size = New System.Drawing.Size(216, 17)
        Me.LBLDel.TabIndex = 11
        Me.LBLDel.Text = "Average bot delay to target (ms):"
        '
        'TXTDel
        '
        Me.TXTDel.Location = New System.Drawing.Point(248, 358)
        Me.TXTDel.Name = "TXTDel"
        Me.TXTDel.Size = New System.Drawing.Size(166, 22)
        Me.TXTDel.TabIndex = 10
        Me.TXTDel.Text = "50"
        '
        'LBLAvgBand
        '
        Me.LBLAvgBand.AutoSize = True
        Me.LBLAvgBand.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLAvgBand.Location = New System.Drawing.Point(37, 390)
        Me.LBLAvgBand.Name = "LBLAvgBand"
        Me.LBLAvgBand.Size = New System.Drawing.Size(205, 17)
        Me.LBLAvgBand.TabIndex = 9
        Me.LBLAvgBand.Text = "Average bot bandwidth (Mbps):"
        '
        'TXTAvgBotBand
        '
        Me.TXTAvgBotBand.Location = New System.Drawing.Point(248, 390)
        Me.TXTAvgBotBand.Name = "TXTAvgBotBand"
        Me.TXTAvgBotBand.Size = New System.Drawing.Size(166, 22)
        Me.TXTAvgBotBand.TabIndex = 8
        Me.TXTAvgBotBand.Text = "100"
        '
        'TXTNumberOfBots
        '
        Me.TXTNumberOfBots.Location = New System.Drawing.Point(248, 323)
        Me.TXTNumberOfBots.Name = "TXTNumberOfBots"
        Me.TXTNumberOfBots.Size = New System.Drawing.Size(166, 22)
        Me.TXTNumberOfBots.TabIndex = 7
        Me.TXTNumberOfBots.Text = "100"
        '
        'LBLNumOfBots
        '
        Me.LBLNumOfBots.AutoSize = True
        Me.LBLNumOfBots.Location = New System.Drawing.Point(133, 323)
        Me.LBLNumOfBots.Name = "LBLNumOfBots"
        Me.LBLNumOfBots.Size = New System.Drawing.Size(109, 17)
        Me.LBLNumOfBots.TabIndex = 6
        Me.LBLNumOfBots.Text = "Number of bots:"
        '
        'GB1
        '
        Me.GB1.Controls.Add(Me.TXTDelay)
        Me.GB1.Controls.Add(Me.TXTBandwidth)
        Me.GB1.Controls.Add(Me.TXTIPv4)
        Me.GB1.Controls.Add(Me.TXTType)
        Me.GB1.Controls.Add(Me.LBLType1)
        Me.GB1.Controls.Add(Me.LBLIP1)
        Me.GB1.Controls.Add(Me.LBLBandwidth1)
        Me.GB1.Controls.Add(Me.LBLDelay1)
        Me.GB1.Location = New System.Drawing.Point(40, 45)
        Me.GB1.Name = "GB1"
        Me.GB1.Size = New System.Drawing.Size(376, 213)
        Me.GB1.TabIndex = 5
        Me.GB1.TabStop = False
        Me.GB1.Text = "Selected host details"
        '
        'TXTDelay
        '
        Me.TXTDelay.Location = New System.Drawing.Point(131, 142)
        Me.TXTDelay.Name = "TXTDelay"
        Me.TXTDelay.ReadOnly = True
        Me.TXTDelay.Size = New System.Drawing.Size(141, 22)
        Me.TXTDelay.TabIndex = 7
        '
        'TXTBandwidth
        '
        Me.TXTBandwidth.Location = New System.Drawing.Point(131, 113)
        Me.TXTBandwidth.Name = "TXTBandwidth"
        Me.TXTBandwidth.ReadOnly = True
        Me.TXTBandwidth.Size = New System.Drawing.Size(141, 22)
        Me.TXTBandwidth.TabIndex = 6
        '
        'TXTIPv4
        '
        Me.TXTIPv4.Location = New System.Drawing.Point(131, 85)
        Me.TXTIPv4.Name = "TXTIPv4"
        Me.TXTIPv4.ReadOnly = True
        Me.TXTIPv4.Size = New System.Drawing.Size(141, 22)
        Me.TXTIPv4.TabIndex = 5
        '
        'TXTType
        '
        Me.TXTType.Location = New System.Drawing.Point(131, 52)
        Me.TXTType.Name = "TXTType"
        Me.TXTType.ReadOnly = True
        Me.TXTType.Size = New System.Drawing.Size(141, 22)
        Me.TXTType.TabIndex = 4
        '
        'LBLType1
        '
        Me.LBLType1.AutoSize = True
        Me.LBLType1.Location = New System.Drawing.Point(40, 52)
        Me.LBLType1.Name = "LBLType1"
        Me.LBLType1.Size = New System.Drawing.Size(44, 17)
        Me.LBLType1.TabIndex = 0
        Me.LBLType1.Text = "Type:"
        '
        'LBLIP1
        '
        Me.LBLIP1.AutoSize = True
        Me.LBLIP1.Location = New System.Drawing.Point(45, 85)
        Me.LBLIP1.Name = "LBLIP1"
        Me.LBLIP1.Size = New System.Drawing.Size(39, 17)
        Me.LBLIP1.TabIndex = 1
        Me.LBLIP1.Text = "IPv4:"
        '
        'LBLBandwidth1
        '
        Me.LBLBandwidth1.AutoSize = True
        Me.LBLBandwidth1.Location = New System.Drawing.Point(7, 118)
        Me.LBLBandwidth1.Name = "LBLBandwidth1"
        Me.LBLBandwidth1.Size = New System.Drawing.Size(77, 17)
        Me.LBLBandwidth1.TabIndex = 2
        Me.LBLBandwidth1.Text = "Bandwidth:"
        '
        'LBLDelay1
        '
        Me.LBLDelay1.AutoSize = True
        Me.LBLDelay1.Location = New System.Drawing.Point(36, 147)
        Me.LBLDelay1.Name = "LBLDelay1"
        Me.LBLDelay1.Size = New System.Drawing.Size(48, 17)
        Me.LBLDelay1.TabIndex = 3
        Me.LBLDelay1.Text = "Delay:"
        '
        'LBLBotnetType
        '
        Me.LBLBotnetType.AutoSize = True
        Me.LBLBotnetType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLBotnetType.Location = New System.Drawing.Point(113, 284)
        Me.LBLBotnetType.Name = "LBLBotnetType"
        Me.LBLBotnetType.Size = New System.Drawing.Size(129, 18)
        Me.LBLBotnetType.TabIndex = 4
        Me.LBLBotnetType.Text = "Select botnet type:"
        '
        'CBBotnetType
        '
        Me.CBBotnetType.BackColor = System.Drawing.SystemColors.Window
        Me.CBBotnetType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CBBotnetType.FormattingEnabled = True
        Me.CBBotnetType.Items.AddRange(New Object() {"Computer based", "IoT based", "Mix"})
        Me.CBBotnetType.Location = New System.Drawing.Point(248, 283)
        Me.CBBotnetType.Name = "CBBotnetType"
        Me.CBBotnetType.Size = New System.Drawing.Size(166, 24)
        Me.CBBotnetType.TabIndex = 3
        Me.CBBotnetType.Text = "Mix"
        '
        'MainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1902, 1033)
        Me.Controls.Add(Me.SplitContainer)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MainWindow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DDoS Visualization Program"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer.Panel2.ResumeLayout(False)
        Me.SplitContainer.Panel2.PerformLayout()
        CType(Me.SplitContainer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer.ResumeLayout(False)
        Me.GB1.ResumeLayout(False)
        Me.GB1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SplitContainer As SplitContainer
    Friend WithEvents GB1 As GroupBox
    Friend WithEvents TXTDelay As TextBox
    Friend WithEvents TXTBandwidth As TextBox
    Friend WithEvents TXTIPv4 As TextBox
    Public WithEvents TXTType As TextBox
    Public WithEvents LBLType1 As Label
    Public WithEvents LBLIP1 As Label
    Public WithEvents LBLBandwidth1 As Label
    Public WithEvents LBLDelay1 As Label
    Friend WithEvents LBLBotnetType As Label
    Friend WithEvents CBBotnetType As ComboBox
    Friend WithEvents TXTNumberOfBots As TextBox
    Friend WithEvents LBLNumOfBots As Label
    Friend WithEvents LBLAvgBand As Label
    Friend WithEvents TXTAvgBotBand As TextBox
    Friend WithEvents TXTDel As TextBox
    Friend WithEvents BTNGenerate As Button
    Friend WithEvents LBLDel As Label
    Friend WithEvents LBLRefServerBand As Label
    Friend WithEvents TXTRefBand As TextBox
    Friend WithEvents TXTTargetBand As TextBox
    Friend WithEvents LBLTargetBand As Label
    Friend WithEvents BTNAbout As Button
End Class
