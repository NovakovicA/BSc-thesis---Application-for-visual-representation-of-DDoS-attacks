﻿Public Class MainWindow

    Private random As New Random()
    Public TXT_Type As TextBox
    Public TXT_IPv4 As TextBox
    Public TXT_Bandwidth As TextBox
    Public TXT_Delay As TextBox


    Public botnetServer As Server
    Public botnetMaster As BotMaster
    Public reflectionServers(2) As Server
    Public target As Server

    Public Internet As Internet

    Private Sub MainWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.SetStyle(ControlStyles.UserPaint, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)
        Me.SetStyle(ControlStyles.OptimizedDoubleBuffer, True)

        Control.CheckForIllegalCrossThreadCalls = False

        TXT_Type = TXTType
        TXT_IPv4 = TXTIPv4
        TXT_Bandwidth = TXTBandwidth
        TXT_Delay = TXTDelay
    End Sub

    Private Sub Draw_Network(sender As Object, e As PaintEventArgs) Handles SplitContainer.Panel1.Paint
        Try
            For Each h As Bot In Bots
                If h.Visible() = True Then
                    h.drawConnection()
                End If
            Next
            botnetServer.drawConnection()
            botnetMaster.drawConnection()
            target.drawConnection()
            For i = 0 To 2
                reflectionServers(i).drawConnection()
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub BTNGenerate_Click(sender As Object, e As EventArgs) Handles BTNGenerate.Click
        If Not IsNumeric(TXTNumberOfBots.Text) Then
            MessageBox.Show("Number of bots must be an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTAvgBotBand.Text) Then
            MessageBox.Show("Average bot bandwidth must be an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTDel.Text) Then
            MessageBox.Show("Average delay must be an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTTargetBand.Text) Then
            MessageBox.Show("Target bandwidth must be an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf Not IsNumeric(TXTRefBand.text) Then
            MessageBox.Show("Reflection server bandwidth must be an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If (CInt(TXTNumberOfBots.Text) < 1) Then
            MessageBox.Show("Number of bots must be greater than 0.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf (CInt(TXTAvgBotBand.Text) < 1) Then
            MessageBox.Show("Average bandwidth must be greater than 0 Mbps.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf (CInt(TXTDel.Text) < 1) Then
            MessageBox.Show("Average delay must be greater than 0 ms.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf (CInt(TXTTargetBand.Text) < 1) Then
            MessageBox.Show("Target bandwidth must be greater than 0 Mbps.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        ElseIf (CInt(TXTRefBand.text) < 1) Then
            MessageBox.Show("Reflection server bandwidth must be greater than 0 Mbps.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If


        For Each b As Bot In Bots
            b.hideImage()
        Next
        Try
            botnetServer.hideImage()
            botnetMaster.hideImage()
            Internet.hideImage()
            target.hideImage()
            target.KillThread()
            For i = 0 To 2
                reflectionServers(i).hideImage()
            Next
        Catch ex As Exception
        End Try


        Bots.Clear()
        Servers.Clear()
        InternetIPs.Clear()
        GC.Collect()

        Dim numberOfHosts As Integer = CInt(TXTNumberOfBots.Text)

        Internet = New Internet(700, 300)

        botnetServer = New Server("2.2.2.2", 10000, "Botnet Server", 1250, 600, True, "botnet.com", New Botnet())
        botnetServer.drawConnection()

        target = New Server("1.1.1.1", TXTTargetBand.Text, "Target", 100, 400, True, "target.com", New TargetSite())
        target.AddOpenPort(53)
        target.drawConnection()

        botnetMaster = New BotMaster(1350, 400)
        botnetMaster.drawConnection()

        For i = 0 To 2
            reflectionServers(i) = New Server(CStr(i + 3) & "." & CStr(i + 3) & "." & CStr(i + 3) & "." & CStr(i + 3), TXTRefBand.Text, "Reflection Server#" & (i + 1), 700 + (i * 200), 700)
            reflectionServers(i).drawConnection()
        Next

        If CBBotnetType.SelectedIndex = 0 Then
            For i = 0 To numberOfHosts - 1
                Dim host As Bot = New Bot(random.Next(0, 3), random.Next(1, CInt(TXTAvgBotBand.Text) * 2), random.Next(1, CInt(TXTDel.Text) * 2), 150 * (i Mod maxDisplay) + 50, 100)
                If i < maxDisplay Then
                    host.showImage()
                    host.drawConnection()
                End If
            Next
        ElseIf CBBotnetType.SelectedIndex = 1 Then
            For i = 0 To numberOfHosts - 1
                Dim host As Bot = New Bot(random.Next(3, 5), random.Next(1, CInt(TXTAvgBotBand.Text) * 2), random.Next(1, CInt(TXTDel.Text) * 2), 150 * (i Mod maxDisplay) + 50, 100)
                If i < maxDisplay Then
                    host.showImage()
                    host.drawConnection()
                End If
            Next
        Else
            For i = 0 To numberOfHosts - 1
                Dim host As Bot = New Bot(random.Next(0, 5), random.Next(1, CInt(TXTAvgBotBand.Text) * 2), random.Next(1, CInt(TXTDel.Text) * 2), 150 * (i Mod maxDisplay) + 50, 100)
                If i < maxDisplay Then
                    host.showImage()
                    host.drawConnection()
                End If
            Next
        End If
        currentDisplayIndex = 0
    End Sub

    Private Sub BTNAbout_Click(sender As Object, e As EventArgs) Handles BTNAbout.Click
        Dim about As New About
        about.Show()
    End Sub
End Class
