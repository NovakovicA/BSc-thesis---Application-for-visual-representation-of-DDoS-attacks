﻿Public Class Bot

    Private IPv4 As String
    Private bandwidth As Integer 'u Mbps
    Private delay As Integer     'u ms
    Private Type As Integer
    Private Status As String = "Idle"
    Private currentBandwidth As Integer = 0

    Public WithEvents display As New PictureBox
    Public info As New Label
    Public info2 As New Label
    Private isVisible As Boolean = False

    Private Shared random As New Random()

    Public Function GetIPv4() As String
        Return IPv4
    End Function

    Public Function GetBandwidth() As Integer
        Return bandwidth
    End Function

    Public Function GetDelay() As Integer
        Return delay
    End Function

    Public Function GetTypeHost() As Integer
        Return Type
    End Function

    Public Function GetStatus() As String
        Return Status
    End Function

    Public Sub SetStatus(ByVal s As String)
        Status = s
    End Sub

    Public Function GetCurrentBandwidth() As Integer
        Return currentBandwidth
    End Function

    Public Sub SetCurrentBandwidth(ByVal band As Integer)
        If (band < 0) Then
            currentBandwidth = 0
        Else
            currentBandwidth = band
        End If
        SetLinkUsage(100 * Convert.ToDouble(currentBandwidth) \ Convert.ToDouble(bandwidth))
    End Sub

    Private Sub SetLinkUsage(ByVal link As Integer)
        If (link < 0) Then
            info2.Text = "0%"
            info2.ForeColor = Color.Green
        ElseIf (link >= 100) Then
            info2.Text = "100%"
            info2.ForeColor = Color.Red
        Else
            info2.Text = CInt(link) & "%"
            If CInt(link) > 75 Then
                info2.ForeColor = Color.Orange
            Else
                info2.ForeColor = Color.Green
            End If
        End If
    End Sub

    Private Shared Function isGoodIp(ByVal ipInput As String) As Boolean
        For Each ip As String In InternetIPs
            If (String.Compare(ip, ipInput) = 0) Then
                Return False
            End If
        Next

        Dim octets(4) As Integer
        Dim octetsString() As String = ipInput.Split("."), ind As Integer = 0
        For Each o As String In octetsString
            If (String.Compare(o, "") <> 0) Then
                octets(ind) = CInt(o)
            End If
            ind += 1
        Next

        If (octets(0) = 255 Or octets(0) = 0 Or octets(0) = 10) _
            Or (octets(0) = 172 And ((octets(1) >= 16) And (octets(1) <= 31))) _
            Or (octets(0) = 192 And octets(1) = 168) Then
            Return False
        End If
        Return True
    End Function

    Public Shared Function generateIPv4() As String
        Dim ret As String = ""
        For i = 0 To 3
            ret += CStr(random.Next(0, 255))
            If (i <> 3) Then : ret += "." : End If
        Next
        Return ret
    End Function

    Public Sub New(ByVal t As Integer, ByVal B As Integer, ByVal d As Integer, ByVal X As Integer, ByVal Y As Integer)
        bandwidth = B : delay = d
        Dim ip As String = generateIPv4()
        While Not isGoodIp(ip)
            ip = generateIPv4()
        End While
        IPv4 = ip
        InternetIPs.Enqueue(IPv4)
        Bots.Enqueue(Me)
        display.BorderStyle = System.Windows.Forms.BorderStyle.None
        display.Location = New System.Drawing.Point(X, Y)
        display.Size = New System.Drawing.Size(50, 50)
        Select Case t
            Case 1
                display.BackgroundImage = My.Resources.desktop
            Case 2
                display.BackgroundImage = My.Resources.laptop
            Case 3
                display.BackgroundImage = My.Resources.router
            Case 4
                display.BackgroundImage = My.Resources.cam
            Case Else
                display.BackgroundImage = My.Resources.server
        End Select
        Type = t
        display.BackgroundImageLayout = ImageLayout.Stretch
        info.Location = New System.Drawing.Point(X - 50, Y - 30)
        info.Text = "Bot#" & Bots.Count
        info.AutoSize = True
        info.Font = New Font("Microsoft Sans Serif", 12, FontStyle.Underline)

        info2.Location = New System.Drawing.Point(X + 50, Y + 30)
        info2.Text = "0%"
        info2.AutoSize = True
        info2.Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        info2.ForeColor = Color.Green
    End Sub

    Public Sub showImage()
        isVisible = True
        MainWindow.SplitContainer.Panel1.Controls.Add(display)
        MainWindow.SplitContainer.Panel1.Controls.Add(info)
        MainWindow.SplitContainer.Panel1.Controls.Add(info2)
        display.Show()
        info.Show()
        info2.Show()
    End Sub

    Public Sub hideImage()
        isVisible = False
        display.Hide()
        info.Hide()
        info2.Hide()
        MainWindow.SplitContainer.Panel1.Controls.Remove(display)
        MainWindow.SplitContainer.Panel1.Controls.Remove(info)
        MainWindow.SplitContainer.Panel1.Controls.Remove(info2)
    End Sub

    Public Function Visible() As Boolean
        Return isVisible
    End Function

    Public Sub drawConnection()
        If (Not moving) Then
            Dim myPen As New System.Drawing.Pen(System.Drawing.Color.Green)
            myPen.Width = 5
            myPen.DashStyle = Drawing2D.DashStyle.Dash
            Dim formGraphics As System.Drawing.Graphics
            formGraphics = MainWindow.SplitContainer.Panel1.CreateGraphics()
            formGraphics.DrawLine(myPen, display.Location.X + (display.Size.Width \ 2), display.Location.Y + (display.Size.Height \ 2), MainWindow.Internet.GetLocation().X + (MainWindow.Internet.GetWidth() \ 2), MainWindow.Internet.GetLocation().Y + (MainWindow.Internet.GetHeight() \ 2))
            myPen.Dispose()
            formGraphics.Dispose()
        End If
    End Sub

    Private Sub Display_Click(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Left Then
            Select Case Type
                Case 1
                    MainWindow.TXT_Type.Text = "Desktop"
                Case 2
                    MainWindow.TXT_Type.Text = "Laptop"
                Case 3
                    MainWindow.TXT_Type.Text = "Router"
                Case 4
                    MainWindow.TXT_Type.Text = "Webcam"
                Case Else
                    MainWindow.TXT_Type.Text = "Server"
            End Select
            MainWindow.TXT_IPv4.Text = IPv4
            MainWindow.TXT_Bandwidth.Text = CStr(bandwidth) & " Mbps"
            MainWindow.TXT_Delay.Text = CStr(delay) & " ms"
        ElseIf e.Button = MouseButtons.Right Then
            Dim menu As ContextMenuStrip = New ContextMenuStrip
            Dim i1 As ToolStripItem = menu.Items.Add("Network Log"), i2 As ToolStripItem, i3 As ToolStripItem, i4 As ToolStripItem

            Select Case Type
                Case 1
                    i2 = menu.Items.Add("Open GUI")
                    i2.Image = My.Resources.gui
                    AddHandler i2.Click, AddressOf OpenGUI
                Case 2
                    i2 = menu.Items.Add("Open GUI")
                    i2.Image = My.Resources.gui
                    AddHandler i2.Click, AddressOf OpenGUI
                Case 3
                    i2 = menu.Items.Add("Open terminal")
                    i2.Image = My.Resources.terminal
                    AddHandler i2.Click, AddressOf OpenTerminal
                Case 4
                    i2 = menu.Items.Add("Open terminal")
                    i2.Image = My.Resources.terminal
                    AddHandler i2.Click, AddressOf OpenTerminal
                Case Else
                    i2 = menu.Items.Add("Open GUI")
                    i2.Image = My.Resources.gui
                    AddHandler i2.Click, AddressOf OpenGUI
            End Select
            i3 = menu.Items.Add("Switch to next group")
            i3.Image = My.Resources.swap

            i4 = menu.Items.Add("Switch to previous group")
            i4.Image = My.Resources.swap

            i1.Image = My.Resources.networklog
            AddHandler i1.Click, AddressOf OpenNetworkLog
            AddHandler i3.Click, AddressOf ShowNextGroup
            AddHandler i4.Click, AddressOf ShowPreviousGroup
            menu.Show(CType(sender, Control), e.Location)
        End If
    End Sub

    Private NetworkLog As String = ""

    Public Sub ResetLog()
        NetworkLog = ""
    End Sub

    Public Sub AddLogEntry(ByVal entry As String)
        NetworkLog = NetworkLog & "[" & DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") & "] " & entry & vbNewLine
    End Sub

    Public Function GetNetworkLog() As String
        Return NetworkLog
    End Function

    Private Sub OpenNetworkLog()
        Dim nl As NetworkLog = New NetworkLog
        nl.SetHost(Me)
        nl.Show()
    End Sub

    Public Sub OpenTerminal()
        Dim tl As Terminal = New Terminal
        tl.SetHost(Me)
        tl.Show()
    End Sub

    Public Sub OpenGUI()
        Dim tl As GUI = New GUI
        tl.SetHost(Me)
        tl.Show()
    End Sub

    Public Shared Sub ShowNextGroup()
        If maxDisplay > Bots.Count Then
            Return
        ElseIf (currentDisplayIndex + maxDisplay > Bots.Count - 1) Then
            For i As Integer = currentDisplayIndex To Bots.Count - 1
                Bots(i).hideImage()
            Next
            currentDisplayIndex = 0
        Else
            For i As Integer = currentDisplayIndex To currentDisplayIndex + maxDisplay - 1
                Bots(i).hideImage()
            Next
            currentDisplayIndex += maxDisplay
        End If

        MainWindow.SplitContainer.Panel1.Refresh()

        For i As Integer = currentDisplayIndex To currentDisplayIndex + maxDisplay - 1
            If (i > Bots.Count - 1) Then
                Exit For
            End If
            Bots(i).showImage()
            Bots(i).drawConnection()
        Next

    End Sub

    Public Shared Sub ShowPreviousGroup()
        If maxDisplay > Bots.Count Then
            Return
        ElseIf (currentDisplayIndex - maxDisplay < 0) Then
            For i As Integer = currentDisplayIndex To currentDisplayIndex + maxDisplay - 1
                If (i > Bots.Count - 1) Then
                    Exit For
                End If
                Bots(i).hideImage()
            Next
            currentDisplayIndex = 0
            While (currentDisplayIndex + maxDisplay <= Bots.Count() - 1)
                currentDisplayIndex += maxDisplay
            End While
        Else
            For i As Integer = currentDisplayIndex To currentDisplayIndex + maxDisplay - 1
                If (i > Bots.Count - 1) Then
                    Exit For
                End If
                Bots(i).hideImage()
            Next
            currentDisplayIndex -= maxDisplay

        End If

        MainWindow.SplitContainer.Panel1.Refresh()

        For i As Integer = currentDisplayIndex To currentDisplayIndex + maxDisplay - 1
            If (i > Bots.Count - 1) Then
                Exit For
            End If
            Bots(i).showImage()
            Bots(i).drawConnection()
        Next

    End Sub


    Dim oldXd As Integer
    Dim oldYd As Integer
    Dim moving As Boolean

    Private Sub Display_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.SizeAll
            oldXd = display.Location.X
            oldYd = display.Location.Y
            moving = True
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub

    Private Sub Display_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseUp
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.Default
            Dim newPosXd As Integer = e.X + oldXd - display.Width \ 2
            Dim newPosYd As Integer = e.Y + oldYd - display.Height \ 2
            Dim newPosXi As Integer = newPosXd - 50
            Dim newPosYi As Integer = newPosYd - 30
            Dim newPosXi2 As Integer = newPosXd + 50
            Dim newPosYi2 As Integer = newPosYd + 30

            Dim xMin As Integer = MainWindow.Internet.GetLocation().X - 30
            Dim xMax As Integer = MainWindow.Internet.GetLocation().X + MainWindow.Internet.GetWidth() + 30

            Dim yMin As Integer = MainWindow.Internet.GetLocation().Y - 30
            Dim yMax As Integer = MainWindow.Internet.GetLocation().Y + MainWindow.Internet.GetHeight() + 30

            If (Not (newPosXd > xMin And newPosXd < xMax And newPosYd > yMin And newPosYd < yMax)) Then
                display.Location = New System.Drawing.Point(newPosXd, newPosYd)
                info.Location = New System.Drawing.Point(newPosXi, newPosYi)
                info2.Location = New System.Drawing.Point(newPosXi2, newPosYi2)
            End If
            moving = False
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub


End Class
