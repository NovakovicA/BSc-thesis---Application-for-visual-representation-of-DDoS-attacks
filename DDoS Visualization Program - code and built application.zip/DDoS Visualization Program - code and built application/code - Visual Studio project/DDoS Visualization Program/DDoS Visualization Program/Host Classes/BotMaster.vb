﻿Public Class BotMaster

    Private IPv4 As String

    Public WithEvents display As New PictureBox
    Public info As New Label

    Private Shared random As New Random()

    Public Function GetIPv4() As String
        Return IPv4
    End Function

    Private Shared Function isGoodIp(ByVal ipInput As String) As Boolean
        For Each ip As String In InternetIPs
            If (String.Compare(ip, ipInput) = 0) Then
                Return False
            End If
        Next

        Dim octets(4) As Integer
        Dim octetsString() As String = ipInput.Split("."), ind As Integer = 0
        For Each o As String In octetsString
            If (String.Compare(o, "") <> 0) Then
                octets(ind) = CInt(o)
            End If
            ind += 1
        Next

        If (octets(0) = 255 Or octets(0) = 0 Or octets(0) = 10) _
            Or (octets(0) = 172 And ((octets(1) >= 16) And (octets(1) <= 31))) _
            Or (octets(0) = 192 And octets(1) = 168) Then
            Return False
        End If
        Return True
    End Function

    Public Shared Function generateIPv4() As String
        Dim ret As String = ""
        For i = 0 To 3
            ret += CStr(random.Next(0, 255))
            If (i <> 3) Then : ret += "." : End If
        Next
        Return ret
    End Function

    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Dim ip As String = generateIPv4()
        While Not isGoodIp(ip)
            ip = generateIPv4()
        End While
        IPv4 = ip
        InternetIPs.Enqueue(IPv4)

        display.BorderStyle = System.Windows.Forms.BorderStyle.None
        display.Location = New System.Drawing.Point(X, Y)
        display.Size = New System.Drawing.Size(75, 75)
        display.BackgroundImage = My.Resources.botmaster
        display.BackgroundImageLayout = ImageLayout.Stretch

        display.Show()
        MainWindow.SplitContainer.Panel1.Controls.Add(display)

        info.Location = New System.Drawing.Point(X - 50, Y - 30)
        info.Text = "Bot Master"
        info.AutoSize = True
        info.Font = New Font("Microsoft Sans Serif", 12, FontStyle.Underline)
        info.Show()
        MainWindow.SplitContainer.Panel1.Controls.Add(info)

    End Sub

    Public Sub drawConnection()
        If (Not moving) Then
            Dim myPen As New System.Drawing.Pen(System.Drawing.Color.Green)
            myPen.Width = 5
            myPen.DashStyle = Drawing2D.DashStyle.Dash
            Dim formGraphics As System.Drawing.Graphics
            formGraphics = MainWindow.SplitContainer.Panel1.CreateGraphics()
            formGraphics.DrawLine(myPen, display.Location.X + (display.Size.Width \ 2), display.Location.Y + (display.Size.Height \ 2), MainWindow.Internet.GetLocation().X + (MainWindow.Internet.GetWidth() \ 2), MainWindow.Internet.GetLocation().Y + (MainWindow.Internet.GetHeight() \ 2))
            myPen.Dispose()
            formGraphics.Dispose()
        End If
    End Sub

    Private Sub Display_Click(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Right Then
            Dim menu As ContextMenuStrip = New ContextMenuStrip
            Dim i1 As ToolStripItem = menu.Items.Add("OpenGUI")
            AddHandler i1.Click, AddressOf OpenGUI
            i1.Image = My.Resources.gui
            menu.Show(CType(sender, Control), e.Location)
        ElseIf e.Button = MouseButtons.Left Then
            MainWindow.TXT_Type.Text = info.Text.Split("#")(0)
            MainWindow.TXT_IPv4.Text = IPv4
            MainWindow.TXT_Bandwidth.Text = "/"
            MainWindow.TXT_Delay.Text = "/"
        End If
    End Sub

    Public Sub OpenGUI()
        Dim tl As GUI = New GUI
        tl.SetBotMaster(Me)
        tl.Show()
    End Sub


    Dim oldXd As Integer
    Dim oldYd As Integer
    Dim moving As Boolean

    Private Sub Display_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.SizeAll
            oldXd = display.Location.X
            oldYd = display.Location.Y
            moving = True
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub

    Private Sub Display_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseUp
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.Default
            Dim newPosXd As Integer = e.X + oldXd - display.Width \ 2
            Dim newPosYd As Integer = e.Y + oldYd - display.Height \ 2
            Dim newPosXi As Integer = newPosXd - 50
            Dim newPosYi As Integer = newPosYd - 30

            Dim xMin As Integer = MainWindow.Internet.GetLocation().X - 30
            Dim xMax As Integer = MainWindow.Internet.GetLocation().X + MainWindow.Internet.GetWidth() + 30

            Dim yMin As Integer = MainWindow.Internet.GetLocation().Y - 30
            Dim yMax As Integer = MainWindow.Internet.GetLocation().Y + MainWindow.Internet.GetHeight() + 30

            If (Not (newPosXd > xMin And newPosXd < xMax And newPosYd > yMin And newPosYd < yMax)) Then
                display.Location = New System.Drawing.Point(newPosXd, newPosYd)
                info.Location = New System.Drawing.Point(newPosXi, newPosYi)
            End If
            moving = False
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub


    Public Sub hideImage()
        MainWindow.SplitContainer.Panel1.Controls.Remove(info)
        MainWindow.SplitContainer.Panel1.Controls.Remove(display)
    End Sub

End Class
