﻿Public Class Internet
    Private WithEvents display As New PictureBox
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        display.BorderStyle = System.Windows.Forms.BorderStyle.None
        display.Location = New System.Drawing.Point(X, Y)
        display.Size = New System.Drawing.Size(400, 300)
        display.BackgroundImage = My.Resources.internet

        display.BackgroundImageLayout = ImageLayout.Stretch
        display.Show()
        MainWindow.SplitContainer.Panel1.Controls.Add(display)
    End Sub


    Public Function GetLocation() As Point
        Return display.Location
    End Function

    Public Function GetWidth() As Integer
        Return display.Width
    End Function

    Public Function GetHeight() As Integer
        Return display.Height
    End Function



    Dim oldXd As Integer
    Dim oldYd As Integer
    Dim moving As Boolean


    Private Sub Display_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.SizeAll
            oldXd = display.Location.X
            oldYd = display.Location.Y
            moving = True
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub

    Private Sub Display_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseUp
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.Default
            Dim newPosXd As Integer = e.X + oldXd - display.Width \ 2
            Dim newPosYd As Integer = e.Y + oldYd - display.Height \ 2
            display.Location = New System.Drawing.Point(e.X + oldXd - display.Width \ 2, e.Y + oldYd - display.Height \ 2)
            moving = False
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub


    Public Sub hideImage()
        MainWindow.SplitContainer.Panel1.Controls.Remove(display)
    End Sub
End Class

