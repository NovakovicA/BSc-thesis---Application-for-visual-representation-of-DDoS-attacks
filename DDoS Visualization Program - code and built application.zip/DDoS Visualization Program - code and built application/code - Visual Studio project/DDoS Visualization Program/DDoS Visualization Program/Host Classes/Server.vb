﻿Public Class Server
    Private Const PortLimit As Integer = 64000
    Private Const ACKWaitTime As Integer = 5
    Private TCPACKQueue As New Queue(Of Integer)
    Private PortSync As New Object
    Private attackSpeed As Integer = 0
    Private thr1 As System.Threading.Thread = Nothing

    Private IPv4 As String
    Private bandwidth As Integer 'u Mbps
    Private currentBandwidth As Integer = 0

    Private WithEvents display As New PictureBox
    Public info As New Label
    Public info2 As New Label


    Private websiteServer As Boolean
    Private websiteURL As String
    Private website As Site
    Private openTCPPorts As New Queue(Of Integer)

    Public Function GetIPv4() As String
        Return IPv4
    End Function

    Public Function GetBandwidth() As Integer
        Return bandwidth
    End Function

    Public Function GetCurrentBandwidth() As Integer
        Return currentBandwidth
    End Function

    Public Sub SetCurrentBandwidth(ByVal band As Integer)
        If (band < 0) Then
            currentBandwidth = 0
        Else
            currentBandwidth = band
        End If
        SetLinkUsage(100 * Convert.ToDouble(currentBandwidth) \ Convert.ToDouble(bandwidth))
    End Sub

    Public Sub AddOpenPort(ByVal port As Integer)
        openTCPPorts.Enqueue(port)
    End Sub

    Public Function GetOpenPorts() As Queue(Of Integer)
        Return openTCPPorts
    End Function

    Public Sub New(ByVal IP As String, ByVal Band As Integer, ByVal infoLabel As String, ByVal X As Integer, ByVal Y As Integer, Optional ByVal webserv As Boolean = False, Optional ByVal url As String = "", Optional ByVal site As Site = Nothing)
        bandwidth = Band
        IPv4 = IP
        InternetIPs.Enqueue(IPv4)
        Servers.Enqueue(Me)
        display.BorderStyle = System.Windows.Forms.BorderStyle.None
        display.Location = New System.Drawing.Point(X, Y)
        display.Size = New System.Drawing.Size(100, 100)
        If (String.Compare("Botnet Server", infoLabel)) = 0 Then
            display.BackgroundImage = My.Resources.botnetserver
        Else
            display.BackgroundImage = My.Resources.server
        End If

        display.BackgroundImageLayout = ImageLayout.Stretch
        display.Show()
        MainWindow.SplitContainer.Panel1.Controls.Add(display)

        info.Location = New System.Drawing.Point(X - 50, Y - 30)
        info.Text = infoLabel
        info.AutoSize = True
        info.Font = New Font("Microsoft Sans Serif", 12, FontStyle.Underline)
        info.Show()
        MainWindow.SplitContainer.Panel1.Controls.Add(info)



        If (webserv = True) Then
            websiteServer = True
            websiteURL = url
            website = site
            openTCPPorts.Enqueue(80)
        End If
        If ((String.Compare("Target", infoLabel)) = 0) Or infoLabel.StartsWith("Reflection Server") Then
            info2.Location = New System.Drawing.Point(X + 100, Y + 50)
            info2.Text = "0%"
            If (String.Compare("Target", infoLabel)) = 0 Then
                info2.Text = info2.Text & vbNewLine & "Status: Online"
                thr1 = New System.Threading.Thread(AddressOf ACKTimeoutThread)
                thr1.IsBackground = True
                thr1.Start()
            End If
            info2.Font = New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
            info2.ForeColor = Color.Green
            info2.AutoSize = True
            MainWindow.SplitContainer.Panel1.Controls.Add(info2)
        End If
    End Sub

    Private Sub SetLinkUsage(ByVal link As Integer)
        If TCPACKQueue.Count >= PortLimit Then
            If (link > 100) Then
                link = 100
            ElseIf link < 0 Then
                link = 0
            End If

            info2.Text = CInt(link) & "%"
            If (String.Compare("Target", info.Text)) = 0 Then
                info2.Text = info2.Text & vbNewLine & "Status: Offline"
            End If
            info2.ForeColor = Color.Red

        ElseIf (link < 0) Then
            info2.Text = "0%"
            If (String.Compare("Target", info.Text)) = 0 Then
                info2.Text = info2.Text & vbNewLine & "Status: Online"
            End If
            info2.ForeColor = Color.Green
        ElseIf (link >= 100) Then
            info2.Text = "100%"
            If (String.Compare("Target", info.Text)) = 0 Then
                info2.Text = info2.Text & vbNewLine & "Status: Offline"
            End If
            info2.ForeColor = Color.Red
        Else
            info2.Text = CInt(link) & "%"
            If (String.Compare("Target", info.Text)) = 0 Then
                info2.Text = info2.Text & vbNewLine & "Status: Online"
            End If
            If CInt(link) > 75 Then
                info2.ForeColor = Color.Orange
            Else
                info2.ForeColor = Color.Green
            End If
        End If
    End Sub

    Public Sub drawConnection()
        Dim myPen As New System.Drawing.Pen(System.Drawing.Color.Green)
        myPen.Width = 5
        myPen.DashStyle = Drawing2D.DashStyle.Dash
        Dim formGraphics As System.Drawing.Graphics
        formGraphics = MainWindow.SplitContainer.Panel1.CreateGraphics()
        formGraphics.DrawLine(myPen, display.Location.X + (display.Size.Width \ 2), display.Location.Y + (display.Size.Height \ 2), MainWindow.Internet.GetLocation().X + (MainWindow.Internet.GetWidth() \ 2), MainWindow.Internet.GetLocation().Y + (MainWindow.Internet.GetHeight() \ 2))
        myPen.Dispose()
        formGraphics.Dispose()
    End Sub

    Dim oldXd As Integer
    Dim oldYd As Integer
    Dim oldXi As Integer
    Dim oldYi As Integer
    Dim moving As Boolean

    Private Sub Display_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.SizeAll
            oldXd = display.Location.X
            oldYd = display.Location.Y
            oldXi = info.Location.X
            oldYi = info.Location.Y
            moving = True
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub

    Private Sub Display_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles display.MouseUp
        If e.Button = MouseButtons.Left Then
            display.Cursor = Cursors.Default
            display.Location = New System.Drawing.Point(e.X + oldXd - display.Width \ 2, e.Y + oldYd - display.Height \ 2)
            info.Location = New System.Drawing.Point(e.X + oldXi - display.Width \ 2, e.Y + oldYi - display.Height \ 2)
            info2.Location = New System.Drawing.Point(e.X + oldXd - display.Width \ 2 + 100, e.Y + oldYd - display.Height \ 2 + 50)
            moving = False
            MainWindow.ActiveForm.Refresh()
        End If
    End Sub

    Private Sub Display_Click(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles display.MouseDown
        If e.Button = MouseButtons.Right And String.Compare(info.Text, "Botnet Server", True) <> 0 Then
            Dim menu As ContextMenuStrip = New ContextMenuStrip
            Dim i1 As ToolStripItem = menu.Items.Add("Network Log")
            i1.Image = My.Resources.networklog
            AddHandler i1.Click, AddressOf OpenNetworkLog
            menu.Show(CType(sender, Control), e.Location)
        ElseIf e.Button = MouseButtons.Left Then
            MainWindow.TXT_Type.Text = info.Text.Split("#")(0)
            MainWindow.TXT_IPv4.Text = IPv4
            MainWindow.TXT_Bandwidth.Text = CStr(bandwidth) & " Mbps"
            MainWindow.TXT_Delay.Text = "/"
        End If
    End Sub

    Public Sub hideImage()
        MainWindow.SplitContainer.Panel1.Controls.Remove(info)
        MainWindow.SplitContainer.Panel1.Controls.Remove(info2)
        MainWindow.SplitContainer.Panel1.Controls.Remove(display)
    End Sub


    Public Function isWebServer() As Boolean
        Return websiteServer
    End Function

    Public Function getWebsiteURL() As String
        Return websiteURL
    End Function

    Public Function getWebsite() As Site
        Return website
    End Function


    Public Shared Async Function openWebsite(ByVal URL As String) As Task(Of Site)
        Dim ret As ErrorSite = New ErrorSite
        For Each s As Server In Servers
            If (String.Compare(s.GetIPv4(), URL) = 0 Or String.Compare(s.getWebsiteURL(), URL, True) = 0) Then
                If (s.GetCurrentBandwidth() > s.GetBandwidth()) Then
                    Await Task.Delay(2000)
                    ret.setTitleAndBody("The connection has timed out", "The server at " & URL & " is taking too long to respond.")
                    Return ret
                ElseIf (s.TCPACKQueue.Count >= PortLimit) Then
                    Await Task.Delay(2000)
                    ret.setTitleAndBody("The connection has timed out", "The server at " & URL & " is taking too long to respond.")
                    Return ret
                Else
                    Return Activator.CreateInstance(s.getWebsite().GetType())
                End If
            End If
        Next

        Await Task.Delay(3000)

        ret.setTitleAndBody("Error website not found", "Please check if the address that you specified is correct. If you still cannot connect, check your network connection.")
        Return ret
    End Function

    Public Shared Function resolveURLtoIP(ByVal URL As String) As String
        For Each s As Server In Servers
            If (String.Compare(s.getWebsiteURL(), URL, True) = 0) Then
                Return s.GetIPv4()
            End If
        Next
        Return Nothing
    End Function




    Private NetworkLog As String = ""

    Public Sub ResetLog()
        NetworkLog = ""
    End Sub

    Public Sub AddLogEntry(ByVal entry As String)
        NetworkLog = NetworkLog & "[" & DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") & "] " & entry & vbNewLine
    End Sub

    Public Function GetNetworkLog() As String
        Return NetworkLog
    End Function

    Private Sub OpenNetworkLog()
        Dim nl As NetworkLog = New NetworkLog
        nl.SetServer(Me)
        nl.Show()
    End Sub

    Private Sub ACKTimeoutThread()
        Try
            While True
                System.Threading.Thread.Sleep(1000)
                SyncLock (PortSync)
                    Dim queue As New Queue(Of Integer)
                    For Each i As Integer In TCPACKQueue
                        If (i - 1) > 0 Then
                            queue.Enqueue(i - 1)
                        End If
                    Next

                    For i = 1 To attackSpeed
                        queue.Enqueue(ACKWaitTime)
                        If queue.Count >= 128000 Then
                            Exit For
                        End If
                    Next
                    TCPACKQueue = queue

                    If (info2.Text.Contains("Offline")) And TCPACKQueue.Count < PortLimit Then
                        SetLinkUsage(100 * Convert.ToDouble(currentBandwidth) \ Convert.ToDouble(bandwidth))
                    ElseIf (info2.Text.Contains("Online")) And TCPACKQueue.Count > PortLimit Then
                        SetLinkUsage(100 * Convert.ToDouble(currentBandwidth) \ Convert.ToDouble(bandwidth))
                    End If
                End SyncLock
            End While
        Catch ex As Exception
        End Try
    End Sub

    Public Function GetSYNAttackSpeed()
        Return attackSpeed
    End Function

    Public Sub SetSYNAttackSpeed(ByVal aspeed As Integer)
        SyncLock (PortSync)
            If (aspeed < 0) Then
                attackSpeed = 0
            Else
                attackSpeed = aspeed
            End If
        End SyncLock
    End Sub

    Public Sub KillThread()
        Try
            If thr1 IsNot Nothing Then
                thr1.Abort()
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class
