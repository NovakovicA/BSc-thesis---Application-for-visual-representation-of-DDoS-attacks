﻿Public Class Terminal
    Private bot As Bot

    Private processNameQueue As New Queue(Of String)
    Private processIDQueue As New Queue(Of String)
    Private processMemoryQueue As New Queue(Of String)
    Private processUserQueue As New Queue(Of String)

    Public Sub SetHost(ByRef host As Bot)
        GenerateProcesses()
        Me.bot = host
        Me.Text = "Terminal - "
        Select Case Me.bot.GetTypeHost()
            Case 1
                Me.Close()
            Case 2
                Me.Close()
            Case 3
                Me.Text = Me.Text & "Router - " & host.info.Text
            Case 4
                Me.Text = Me.Text & "Cam - " & host.info.Text
            Case Else
                Me.Close()
        End Select
        TXTMain.AppendText("Example Linux Terminal" & vbNewLine)
        TXTMain.AppendText("----------------------" & vbNewLine)
        TXTMain.AppendText("Type 'commands' or '?' to view the list of available commands." & vbNewLine & vbNewLine)
    End Sub

    Public Sub EnterCommand(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTCommand.KeyDown
        If e.KeyCode = Keys.Enter And String.Compare(TXTCommand.Text, "") <> 0 Then
            TXTMain.AppendText("Terminal> " & TXTCommand.Text & vbNewLine)
            HandleCommand(TXTCommand.Text)
            TXTCommand.Text = ""
            e.SuppressKeyPress = True
            e.Handled = True
        End If
    End Sub

    Public Sub StopBeep(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTCommand.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            e.Handled = True
        End If
    End Sub

    Public Sub StopBeep2(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTCommand.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            e.Handled = True
        End If
    End Sub


    Public Sub HandleCommand(ByVal command As String)
        If String.Compare(command, "?", True) = 0 Or String.Compare(command, "commands", True) = 0 Then
            TXTMain.AppendText("Available commands:" & vbNewLine)
            TXTMain.AppendText("commands/?         -View list of available commands." & vbNewLine)
            TXTMain.AppendText("ping [IP]          -Pings the provided host." & vbNewLine)
            TXTMain.AppendText("tasklist           -View list of current processes." & vbNewLine)
            TXTMain.AppendText("quit               -Close the terminal." & vbNewLine)
        ElseIf String.Compare(command, "quit", True) = 0 Then
            Me.Close()
            Return
        ElseIf String.Compare(Split(command, " ")(0), "ping", True) = 0 And Split(command, " ").Count() = 2 Then
            Dim IP As String = Split(command, " ")(1)
            TXTMain.AppendText("Pinging " & IP & " with 32 bytes of data:" & vbNewLine)

            If (bot.GetCurrentBandwidth() >= bot.GetBandwidth()) Then
                TXTMain.AppendText("Request timed out." & vbNewLine)
                TXTMain.AppendText("Request timed out." & vbNewLine)
                TXTMain.AppendText("Request timed out." & vbNewLine)
                TXTMain.AppendText("Request timed out." & vbNewLine)
            ElseIf String.Compare(bot.GetIPv4(), IP) = 0 Then
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time<1ms TTL=128" & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time<1ms TTL=128" & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time<1ms TTL=128" & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time<1ms TTL=128" & vbNewLine)
            ElseIf (String.Compare(MainWindow.target.GetIPv4(), IP) = 0) Then
                Dim rdm As New Random
                Dim TTL As Integer = rdm.Next(1, 127)
                If (MainWindow.target.GetBandwidth() > MainWindow.target.GetCurrentBandwidth()) Then
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & bot.GetDelay() & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & bot.GetDelay() & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & bot.GetDelay() & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & bot.GetDelay() & "ms TTL=" & TTL & vbNewLine)
                Else
                    TXTMain.AppendText("Request timed out." & vbNewLine)
                    TXTMain.AppendText("Request timed out." & vbNewLine)
                    TXTMain.AppendText("Request timed out." & vbNewLine)
                    TXTMain.AppendText("Request timed out." & vbNewLine)
                End If


            ElseIf (InternetIPs.Contains(IP)) Then
                Dim rdm As New Random
                Dim time As Integer = rdm.Next(1, 150)
                Dim TTL As Integer = rdm.Next(1, 127)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
            ElseIf (Server.resolveURLtoIP(IP) IsNot Nothing) Then
                IP = Server.resolveURLtoIP(IP)
                Dim rdm As New Random
                Dim time As Integer
                Dim TTL As Integer = rdm.Next(1, 127)
                If (String.Compare(IP, MainWindow.target.GetIPv4(), True) = 0) Then
                    time = bot.GetDelay()
                Else
                    time = rdm.Next(1, 150)
                End If

                TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                    TXTMain.AppendText("Reply from " & IP & ": bytes 32 time=" & time & "ms TTL=" & TTL & vbNewLine)
                Else
                    TXTMain.AppendText("Ping request failed." & vbNewLine)
                TXTMain.AppendText("Ping request failed." & vbNewLine)
                TXTMain.AppendText("Ping request failed." & vbNewLine)
                TXTMain.AppendText("Ping request failed." & vbNewLine)
            End If
        ElseIf String.Compare(command, "tasklist", True) = 0 Then
            ShowProcesses()
        Else
            TXTMain.AppendText("Unrecognized command." & vbNewLine)
        End If
        TXTMain.AppendText(vbNewLine)
        TXTMain.Invoke(New MethodInvoker(AddressOf TXTMain.ScrollToCaret))
    End Sub

    Private Sub ShowProcesses()
        Dim maxPNameLen As Integer = 13, maxPIDLen As Integer = 3, maxPMemLen As Integer = 7, maxPUserLen As Integer = 4
        For i = 0 To processNameQueue.Count() - 1
            If (processNameQueue(i).Length() > maxPNameLen) Then
                maxPNameLen = processNameQueue(i).Length()
            End If
            If (processIDQueue(i).Length() > maxPIDLen) Then
                maxPIDLen = processIDQueue(i).Length()
            End If
            If (processMemoryQueue(i).Length() > maxPMemLen) Then
                maxPMemLen = processMemoryQueue(i).Length()
            End If
            If (processUserQueue(i).Length() > maxPUserLen) Then
                maxPUserLen = processUserQueue(i).Length()
            End If
        Next

        TXTMain.AppendText("Process Name ")
        For i = 12 To maxPNameLen
            TXTMain.AppendText("  ")
        Next
        TXTMain.AppendText("ID ")
        For i = 12 To maxPIDLen
            TXTMain.AppendText("  ")
        Next
        TXTMain.AppendText("Memory ")
        For i = 12 To maxPMemLen
            TXTMain.AppendText("  ")
        Next
        TXTMain.AppendText("User")
        For i = 12 To maxPUserLen
            TXTMain.AppendText("  ")
        Next

        TXTMain.AppendText(vbNewLine)

        For i = 1 To maxPNameLen
            TXTMain.AppendText("=")
        Next
        TXTMain.AppendText(" ")
        For i = 1 To maxPIDLen
            TXTMain.AppendText("=")
        Next
        TXTMain.AppendText(" ")
        For i = 1 To maxPMemLen
            TXTMain.AppendText("=")
        Next
        TXTMain.AppendText(" ")
        For i = 1 To maxPUserLen
            TXTMain.AppendText("=")
        Next

        TXTMain.AppendText(vbNewLine)

        For i = 0 To processNameQueue.Count() - 1
            If String.Compare(processNameQueue(i), "Botnet malware") = 0 Then
                TXTMain.SelectionColor = Color.Red
            End If

            TXTMain.AppendText(processNameQueue(i))
            For j = processNameQueue(i).Length() To maxPNameLen
                TXTMain.AppendText("   ")
            Next
            TXTMain.AppendText(processIDQueue(i))
            For j = processIDQueue(i).Length() To maxPIDLen
                TXTMain.AppendText("   ")
            Next
            TXTMain.AppendText(processMemoryQueue(i))
            For j = processMemoryQueue(i).Length() To maxPMemLen
                TXTMain.AppendText("   ")
            Next
            TXTMain.AppendText(processUserQueue(i))
            For j = processMemoryQueue(i).Length() To maxPUserLen
                TXTMain.AppendText("   ")
            Next
            TXTMain.AppendText(vbNewLine)

            If String.Compare(processNameQueue(i), "Botnet malware") = 0 Then
                TXTMain.SelectionColor = Color.White
            End If
        Next

    End Sub

    Private Sub GenerateProcesses()
        processNameQueue.Clear()
        processIDQueue.Clear()
        processMemoryQueue.Clear()
        processUserQueue.Clear()

        Dim random As New Random()
        Dim numOfSystem As Integer = random.Next(3, 10)
        Dim numOfUser As Integer = random.Next(5, 15)

        For ind = 1 To numOfSystem
            processNameQueue.Enqueue("System Process - " & ind)
            processIDQueue.Enqueue(100 + ind)
            processMemoryQueue.Enqueue(random.Next(1000, 10000) & " K")
            processUserQueue.Enqueue("SYSTEM")
        Next

        For ind = 1 To numOfUser
            processNameQueue.Enqueue("User Process - " & ind)
            processIDQueue.Enqueue(1000 + ind)
            processMemoryQueue.Enqueue(random.Next(5000, 50000) & " K")
            processUserQueue.Enqueue("User")
        Next

        processNameQueue.Enqueue("Botnet malware")
        processIDQueue.Enqueue(1000 + numOfUser + 1)
        processMemoryQueue.Enqueue(random.Next(5000, 7500) & " K")
        processUserQueue.Enqueue("User")
    End Sub

End Class