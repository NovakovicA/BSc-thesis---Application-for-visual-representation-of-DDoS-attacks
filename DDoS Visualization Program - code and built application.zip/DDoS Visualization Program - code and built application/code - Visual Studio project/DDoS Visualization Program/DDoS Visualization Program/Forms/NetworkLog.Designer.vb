﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NetworkLog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NetworkLog))
        Me.BTNClose = New System.Windows.Forms.Button()
        Me.BTNClearLog = New System.Windows.Forms.Button()
        Me.TXTLog = New System.Windows.Forms.TextBox()
        Me.BTNRefresh = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BTNClose
        '
        Me.BTNClose.Location = New System.Drawing.Point(600, 3)
        Me.BTNClose.Name = "BTNClose"
        Me.BTNClose.Size = New System.Drawing.Size(84, 36)
        Me.BTNClose.TabIndex = 0
        Me.BTNClose.Text = "Close"
        Me.BTNClose.UseVisualStyleBackColor = True
        '
        'BTNClearLog
        '
        Me.BTNClearLog.Location = New System.Drawing.Point(496, 3)
        Me.BTNClearLog.Name = "BTNClearLog"
        Me.BTNClearLog.Size = New System.Drawing.Size(97, 36)
        Me.BTNClearLog.TabIndex = 1
        Me.BTNClearLog.Text = "Clear log"
        Me.BTNClearLog.UseVisualStyleBackColor = True
        '
        'TXTLog
        '
        Me.TXTLog.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TXTLog.Location = New System.Drawing.Point(0, 45)
        Me.TXTLog.Multiline = True
        Me.TXTLog.Name = "TXTLog"
        Me.TXTLog.ReadOnly = True
        Me.TXTLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TXTLog.Size = New System.Drawing.Size(727, 408)
        Me.TXTLog.TabIndex = 2
        '
        'BTNRefresh
        '
        Me.BTNRefresh.Location = New System.Drawing.Point(393, 3)
        Me.BTNRefresh.Name = "BTNRefresh"
        Me.BTNRefresh.Size = New System.Drawing.Size(97, 36)
        Me.BTNRefresh.TabIndex = 3
        Me.BTNRefresh.Text = "Refresh log"
        Me.BTNRefresh.UseVisualStyleBackColor = True
        '
        'NetworkLog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(727, 453)
        Me.ControlBox = False
        Me.Controls.Add(Me.BTNRefresh)
        Me.Controls.Add(Me.TXTLog)
        Me.Controls.Add(Me.BTNClearLog)
        Me.Controls.Add(Me.BTNClose)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "NetworkLog"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Network Log"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNClose As Button
    Friend WithEvents BTNClearLog As Button
    Friend WithEvents TXTLog As TextBox
    Friend WithEvents BTNRefresh As Button
End Class
