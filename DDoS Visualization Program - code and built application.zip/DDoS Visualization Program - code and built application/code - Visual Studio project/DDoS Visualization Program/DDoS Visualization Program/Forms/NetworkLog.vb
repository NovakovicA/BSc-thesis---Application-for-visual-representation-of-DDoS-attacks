﻿Public Class NetworkLog
    Private bot As Bot = Nothing
    Private server As Server = Nothing

    Public Sub SetHost(ByRef bot As Bot)
        Me.bot = bot
        TXTLog.Text = Me.bot.GetNetworkLog()
        Me.Text = "Network Log - "
        Select Case bot.GetTypeHost
            Case 1
                Me.Text = Me.Text & "Desktop - " & bot.info.Text
            Case 2
                Me.Text = Me.Text & "Laptop - " & bot.info.Text
            Case 3
                Me.Text = Me.Text & "Router - " & bot.info.Text
            Case 4
                Me.Text = Me.Text & "Cam - " & bot.info.Text
            Case Else
                Me.Text = Me.Text & "Server - " & bot.info.Text
        End Select
    End Sub

    Public Sub SetServer(ByRef server As Server)
        Me.server = server
        TXTLog.Text = Me.server.GetNetworkLog()
        Me.Text = "Network Log - "
        Me.Text = Me.Text & "Server - " & server.info.Text
    End Sub

    Private Sub BTNClearLog_Click(sender As Object, e As EventArgs) Handles BTNClearLog.Click
        TXTLog.Text = ""
        Try
            If (bot IsNot Nothing) Then
                Me.bot.ResetLog()
            ElseIf (server IsNot Nothing) Then
                Me.server.ResetLog()
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub BTNClose_Click(sender As Object, e As EventArgs) Handles BTNClose.Click
        Me.Close()
    End Sub

    Private Sub BTNRefresh_Click(sender As Object, e As EventArgs) Handles BTNRefresh.Click
        If (bot IsNot Nothing) Then
            TXTLog.Text = bot.GetNetworkLog()
        ElseIf (server IsNot Nothing) Then
            TXTLog.Text = server.GetNetworkLog()
        End If
    End Sub


End Class