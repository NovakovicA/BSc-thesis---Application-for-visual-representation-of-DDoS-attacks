﻿Public Class GUI

    Private bot As Bot = Nothing
    Private bm As BotMaster = Nothing

    Private process As Queue(Of String)
    Private processIDs As Queue(Of String)
    Private processMemory As Queue(Of String)
    Private CPU As Queue(Of String)
    Private User As String = ""


    Private currentWebsite As Site = Nothing

    Public Sub SetHost(ByRef host As Bot)
        Me.bot = host
        Me.Text = "GUI - "
        Select Case Me.bot.GetTypeHost()
            Case 1
                Me.Text = Me.Text & "Desktop - " & host.info.Text
            Case 2
                Me.Text = Me.Text & "Laptop - " & host.info.Text
            Case 3
                Me.Close()
            Case 4
                Me.Close()
            Case Else
                Me.Text = Me.Text & "Server - " & host.info.Text
        End Select
        makeProcessList(True)
    End Sub

    Public Sub SetBotMaster(ByRef bm As BotMaster)
        Me.bm = bm
        Me.Text = "GUI - "
        Me.Text = Me.Text & "Botnet Master - " & bm.GetIPv4()
        makeProcessList(False)
    End Sub

    Public Async Sub EnterWebsite(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTURL.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                If (currentWebsite IsNot Nothing) Then
                    PanelWebsite.Controls.Remove(CType(currentWebsite, Site).Website)
                End If

                If (bot IsNot Nothing) Then
                    If (bot.GetCurrentBandwidth() >= bot.GetBandwidth()) Then
                        Dim err As New ErrorSite
                        Await Task.Delay(2000)
                        PanelWebsite.Controls.Add(err.Website)
                        currentWebsite = err
                        err.setTitleAndBody("The connection has timed out", "The server at " & TXTURL.Text & " is taking too long to respond.")
                        err.WebsiteLoad()
                        Return
                    End If
                End If

                Dim ret As Site = Await Server.openWebsite(TXTURL.Text)
                If (ret IsNot Nothing) Then
                    PanelWebsite.Controls.Add(CType(ret, Site).Website)
                    currentWebsite = ret
                    ret.WebsiteLoad()
                Else
                    currentWebsite = Nothing
                End If

                e.SuppressKeyPress = True
                e.Handled = True
            Catch ex As Exception
            End Try
        End If
    End Sub

    Public Sub StopBeep(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTURL.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            e.Handled = True
        End If
    End Sub

    Public Sub StopBeep2(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXTURL.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            e.Handled = True
        End If
    End Sub

    Private Sub TXTURL_LostFocus(sender As Object, e As EventArgs) Handles TXTURL.LostFocus
        If (String.Compare(TXTURL.Text, "") = 0) Then
            TXTURL.Text = "Enter website URL"
        End If
    End Sub

    Private Sub TXTURL_GotFocus(sender As Object, e As EventArgs) Handles TXTURL.GotFocus
        If (String.Compare(TXTURL.Text, "Enter website URL") = 0) Then
            TXTURL.Text = ""
        End If
    End Sub

    Public Sub makeProcessList(ByVal bot As Boolean)
        ListViewProcess.Items.Clear()
        Dim random As New Random()
        Dim numOfSystem As Integer = random.Next(3, 10)
        Dim numOfUser As Integer = random.Next(5, 15)

        For ind = 1 To numOfSystem
            Dim item As New ListViewItem
            item.Text = "System Process - " & ind
            item.SubItems.Add(100 + ind)
            item.SubItems.Add(random.Next(1000, 10000) & " K")
            item.SubItems.Add("SYSTEM")
            ListViewProcess.Items.Add(item)
        Next

        For ind = 1 To numOfUser
            Dim item As New ListViewItem
            item.Text = "User Process - " & ind
            item.SubItems.Add(1000 + ind)
            item.SubItems.Add(random.Next(5000, 50000) & " K")
            item.SubItems.Add("User")
            ListViewProcess.Items.Add(item)
        Next

        If bot = True Then
            Dim item As New ListViewItem
            item.BackColor = Color.Red
            item.Text = "Botnet malware"
            item.SubItems.Add(1000 + numOfUser + 1)
            item.SubItems.Add(random.Next(5000, 7500) & " K")
            item.SubItems.Add("User")
            ListViewProcess.Items.Add(item)
        End If
    End Sub


End Class