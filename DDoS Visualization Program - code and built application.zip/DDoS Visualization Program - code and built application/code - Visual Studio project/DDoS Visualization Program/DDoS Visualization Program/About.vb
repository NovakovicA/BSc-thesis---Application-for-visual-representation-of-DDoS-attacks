﻿Public Class About
    Private Sub MainPanel_Click(sender As Object, e As EventArgs) Handles MainPanel.Click
        Me.Close()
    End Sub

    Private Sub LBLTitle_Click(sender As Object, e As EventArgs) Handles LBLTitle.Click
        Me.Close()
    End Sub

    Private Sub PBLogo_Click(sender As Object, e As EventArgs) Handles PBLogo.Click
        Me.Close()
    End Sub

    Private Sub LBLMentor_Click(sender As Object, e As EventArgs) Handles LBLMentor.Click
        Me.Close()
    End Sub

    Private Sub LBLAuthor_Click(sender As Object, e As EventArgs) Handles LBLAuthor.Click
        Me.Close()
    End Sub
End Class