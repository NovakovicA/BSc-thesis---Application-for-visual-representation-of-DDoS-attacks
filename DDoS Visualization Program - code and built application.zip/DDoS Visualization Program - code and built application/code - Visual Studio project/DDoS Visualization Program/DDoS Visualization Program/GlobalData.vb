﻿Module GlobalData
    Public Bots As New Queue(Of Bot)
    Public Servers As New Queue(Of Server)
    Public InternetIPs As New Queue(Of String)

    Public maxDisplay As Integer = 10
    Public currentDisplayIndex As Integer = 0
End Module
