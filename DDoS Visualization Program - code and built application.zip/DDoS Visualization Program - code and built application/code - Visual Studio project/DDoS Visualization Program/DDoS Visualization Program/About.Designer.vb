﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class About
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.LBLTitle = New System.Windows.Forms.Label()
        Me.LBLAuthor = New System.Windows.Forms.Label()
        Me.PBLogo = New System.Windows.Forms.PictureBox()
        Me.LBLMentor = New System.Windows.Forms.Label()
        Me.MainPanel.SuspendLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainPanel
        '
        Me.MainPanel.Controls.Add(Me.LBLMentor)
        Me.MainPanel.Controls.Add(Me.LBLTitle)
        Me.MainPanel.Controls.Add(Me.LBLAuthor)
        Me.MainPanel.Controls.Add(Me.PBLogo)
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainPanel.Location = New System.Drawing.Point(0, 0)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(581, 424)
        Me.MainPanel.TabIndex = 0
        '
        'LBLTitle
        '
        Me.LBLTitle.AutoSize = True
        Me.LBLTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLTitle.ForeColor = System.Drawing.Color.Gray
        Me.LBLTitle.Location = New System.Drawing.Point(255, 9)
        Me.LBLTitle.Name = "LBLTitle"
        Me.LBLTitle.Size = New System.Drawing.Size(285, 25)
        Me.LBLTitle.TabIndex = 2
        Me.LBLTitle.Text = "DDoS Visualization Program"
        '
        'LBLAuthor
        '
        Me.LBLAuthor.AutoSize = True
        Me.LBLAuthor.BackColor = System.Drawing.SystemColors.Control
        Me.LBLAuthor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLAuthor.ForeColor = System.Drawing.Color.Gray
        Me.LBLAuthor.Location = New System.Drawing.Point(12, 375)
        Me.LBLAuthor.Name = "LBLAuthor"
        Me.LBLAuthor.Size = New System.Drawing.Size(346, 25)
        Me.LBLAuthor.TabIndex = 1
        Me.LBLAuthor.Text = "Student: Aleksa Novaković 0305/2017"
        '
        'PBLogo
        '
        Me.PBLogo.BackgroundImage = Global.DDoS_Visualization_Program.My.Resources.Resources.logo
        Me.PBLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PBLogo.Location = New System.Drawing.Point(0, 0)
        Me.PBLogo.Name = "PBLogo"
        Me.PBLogo.Size = New System.Drawing.Size(249, 277)
        Me.PBLogo.TabIndex = 0
        Me.PBLogo.TabStop = False
        '
        'LBLMentor
        '
        Me.LBLMentor.AutoSize = True
        Me.LBLMentor.BackColor = System.Drawing.SystemColors.Control
        Me.LBLMentor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLMentor.ForeColor = System.Drawing.Color.Gray
        Me.LBLMentor.Location = New System.Drawing.Point(12, 335)
        Me.LBLMentor.Name = "LBLMentor"
        Me.LBLMentor.Size = New System.Drawing.Size(280, 25)
        Me.LBLMentor.TabIndex = 3
        Me.LBLMentor.Text = "Mentor: dr Žarko Stanisavljević"
        '
        'About
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 424)
        Me.Controls.Add(Me.MainPanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "About"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SplashScreen"
        Me.MainPanel.ResumeLayout(False)
        Me.MainPanel.PerformLayout()
        CType(Me.PBLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MainPanel As Panel
    Friend WithEvents LBLTitle As Label
    Friend WithEvents LBLAuthor As Label
    Friend WithEvents PBLogo As PictureBox
    Friend WithEvents LBLMentor As Label
End Class
